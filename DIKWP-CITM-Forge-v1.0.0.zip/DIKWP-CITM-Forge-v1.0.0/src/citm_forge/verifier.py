"""Safe declarative verifiers for explicitly finite proof obligations.

No arbitrary Python, shell, network, solver, or plugin code is executed from a
project file. Unsupported verifier kinds remain OPEN rather than being guessed.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping

from .canonical import canonical_json, sha256_text
from .model import ObligationState, ProofObligation


def is_prime(value: int) -> bool:
    if value < 2:
        return False
    if value in (2, 3):
        return True
    if value % 2 == 0 or value % 3 == 0:
        return False
    limit = math.isqrt(value)
    candidate = 5
    step = 2
    while candidate <= limit:
        if value % candidate == 0:
            return False
        candidate += step
        step = 6 - step
    return True


def generate_goldbach_witnesses(start: int, end: int) -> dict[str, list[int]]:
    if start < 4 or end < start:
        raise ValueError("Goldbach range must satisfy 4 <= start <= end")
    witnesses: dict[str, list[int]] = {}
    first = start if start % 2 == 0 else start + 1
    for even in range(first, end + 1, 2):
        for left in range(2, even + 1):
            right = even - left
            if is_prime(left) and is_prime(right):
                witnesses[str(even)] = [left, right]
                break
    return witnesses


def verify_goldbach_finite(spec: Mapping[str, Any]) -> dict[str, Any]:
    start = int(spec.get("start", 4))
    end = int(spec.get("end", 0))
    witnesses = spec.get("witnesses")
    if witnesses == "GENERATE" or witnesses is None:
        witnesses = generate_goldbach_witnesses(start, end)
    if not isinstance(witnesses, Mapping):
        return {"state": ObligationState.FAILED.value, "errors": ["witnesses must be a mapping"]}
    errors: list[str] = []
    checked = 0
    first = start if start % 2 == 0 else start + 1
    for even in range(first, end + 1, 2):
        checked += 1
        pair = witnesses.get(str(even))
        if not isinstance(pair, list) or len(pair) != 2:
            errors.append(f"Missing two-number witness for {even}")
            continue
        left, right = int(pair[0]), int(pair[1])
        if left + right != even:
            errors.append(f"Witness {left}+{right} does not equal {even}")
        if not is_prime(left) or not is_prime(right):
            errors.append(f"Witness for {even} contains a non-prime")
    return {
        "state": ObligationState.FAILED.value if errors else ObligationState.VERIFIED.value,
        "verifier_kind": "goldbach_finite",
        "range": {"start": start, "end": end},
        "checked_even_count": checked,
        "witnesses": dict(witnesses),
        "errors": errors,
        "scope_boundary": (
            f"This certificate covers only even integers in [{start}, {end}]. "
            "It is not a proof of the unrestricted strong Goldbach conjecture."
        ),
    }


def _evaluate_relation(relation: Mapping[str, Any]) -> bool:
    kind = str(relation.get("op", ""))
    left = relation.get("left")
    right = relation.get("right")
    if kind == "equal":
        return left == right
    if kind == "not_equal":
        return left != right
    if kind == "gt":
        return float(left) > float(right)
    if kind == "ge":
        return float(left) >= float(right)
    if kind == "lt":
        return float(left) < float(right)
    if kind == "le":
        return float(left) <= float(right)
    if kind == "divides":
        return int(right) % int(left) == 0
    if kind == "is_prime":
        return is_prime(int(left))
    if kind == "sum_equals":
        values = relation.get("values", [])
        return sum(float(value) for value in values) == float(right)
    raise ValueError(f"Unsupported declarative relation: {kind}")


def verify_finite_relations(spec: Mapping[str, Any]) -> dict[str, Any]:
    relations = spec.get("relations", [])
    if not isinstance(relations, list) or not relations:
        return {"state": ObligationState.FAILED.value, "errors": ["relations must be a non-empty list"]}
    results: list[dict[str, Any]] = []
    errors: list[str] = []
    for index, relation in enumerate(relations):
        try:
            passed = _evaluate_relation(relation)
        except (TypeError, ValueError, ZeroDivisionError) as exc:
            passed = False
            errors.append(f"Relation {index}: {exc}")
        if not passed:
            errors.append(f"Relation {index} evaluated false")
        results.append({"index": index, "relation": relation, "passed": passed})
    return {
        "state": ObligationState.FAILED.value if errors else ObligationState.VERIFIED.value,
        "verifier_kind": "finite_relations",
        "results": results,
        "errors": errors,
        "scope_boundary": "Only the enumerated declarative relations were checked.",
    }


def verify_hash_match(spec: Mapping[str, Any]) -> dict[str, Any]:
    value = spec.get("value")
    expected = str(spec.get("sha256", ""))
    actual = sha256_text(canonical_json(value))
    passed = bool(expected) and actual == expected
    return {
        "state": ObligationState.VERIFIED.value if passed else ObligationState.FAILED.value,
        "verifier_kind": "hash_match",
        "expected_sha256": expected,
        "actual_sha256": actual,
        "scope_boundary": "Hash equality proves byte/canonical-object identity, not mathematical truth.",
    }


def verify_truth_table(spec: Mapping[str, Any]) -> dict[str, Any]:
    rows = spec.get("rows", [])
    if not isinstance(rows, list) or not rows:
        return {"state": ObligationState.FAILED.value, "errors": ["rows must be a non-empty list"]}
    errors: list[str] = []
    for index, row in enumerate(rows):
        inputs = [bool(value) for value in row.get("inputs", [])]
        operation = str(row.get("operation", ""))
        expected = bool(row.get("expected"))
        if operation == "and":
            actual = all(inputs)
        elif operation == "or":
            actual = any(inputs)
        elif operation == "xor":
            actual = sum(inputs) % 2 == 1
        elif operation == "not":
            if len(inputs) != 1:
                errors.append(f"Row {index}: not requires one input")
                continue
            actual = not inputs[0]
        else:
            errors.append(f"Row {index}: unsupported operation {operation}")
            continue
        if actual != expected:
            errors.append(f"Row {index}: expected {expected}, got {actual}")
    return {
        "state": ObligationState.FAILED.value if errors else ObligationState.VERIFIED.value,
        "verifier_kind": "truth_table",
        "row_count": len(rows),
        "errors": errors,
        "scope_boundary": "Only the supplied finite truth table was checked.",
    }


def verify_obligation(obligation: ProofObligation) -> dict[str, Any]:
    kind = str(obligation.verifier.get("kind", "external"))
    if kind == "goldbach_finite":
        result = verify_goldbach_finite(obligation.verifier)
    elif kind == "finite_relations":
        result = verify_finite_relations(obligation.verifier)
    elif kind == "hash_match":
        result = verify_hash_match(obligation.verifier)
    elif kind == "truth_table":
        result = verify_truth_table(obligation.verifier)
    elif kind in {"external", "manual_external", "formal_proof_assistant_external"}:
        result = {
            "state": ObligationState.EXTERNAL.value,
            "verifier_kind": kind,
            "reason": str(obligation.verifier.get("reason", "Independent external verification is required")),
            "scope_boundary": "The local runtime does not invent or impersonate an external certificate.",
        }
    else:
        result = {
            "state": ObligationState.OPEN.value,
            "verifier_kind": kind,
            "reason": "Unsupported verifier kind; kept open rather than executed or guessed",
            "scope_boundary": "No arbitrary project-supplied code is executed.",
        }
    return {
        "obligation_id": obligation.id,
        "claim": obligation.claim,
        "scope": obligation.scope,
        "dependencies": list(obligation.dependencies),
        "retirement_conditions": list(obligation.retirement_conditions),
        **result,
    }


def verify_all(obligations: tuple[ProofObligation, ...]) -> dict[str, Any]:
    results = {obligation.id: verify_obligation(obligation) for obligation in obligations}
    states = [result["state"] for result in results.values()]
    if any(state == ObligationState.FAILED.value for state in states):
        overall = ObligationState.FAILED
    elif states and all(state == ObligationState.VERIFIED.value for state in states):
        overall = ObligationState.VERIFIED
    elif not states:
        overall = ObligationState.NOT_APPLICABLE
    else:
        overall = ObligationState.OPEN
    return {"state": overall.value, "results": results}
