"""Validation and audit of the twenty-five D/I/K/W/P route kinds."""

from __future__ import annotations

from collections import defaultdict, deque
from typing import Any, Iterable

from .model import (
    AuditState,
    ConceptAlias,
    RecordKind,
    Route,
    SemanticRecord,
    ensure_unique,
)


ALL_ROUTE_KINDS = tuple(f"{source.value}->{target.value}" for source in RecordKind for target in RecordKind)


def route_kind(route: Route, records: dict[str, SemanticRecord]) -> str:
    return f"{records[route.source].kind.value}->{records[route.target].kind.value}"


class RouteAudit:
    def __init__(
        self,
        records: Iterable[SemanticRecord],
        routes: Iterable[Route],
        aliases: Iterable[ConceptAlias],
    ) -> None:
        self.records = tuple(records)
        self.routes = tuple(routes)
        self.aliases = tuple(aliases)
        self.by_id = {record.id: record for record in self.records}
        self.adjacency: dict[str, list[str]] = defaultdict(list)
        for route in self.routes:
            self.adjacency[route.source].append(route.target)

    def validate(self) -> dict[str, Any]:
        errors: list[str] = []
        warnings: list[str] = []
        ensure_unique((record.id for record in self.records), "record ids")
        ensure_unique((route.id for route in self.routes), "route ids")
        ensure_unique((alias.id for alias in self.aliases), "alias ids")

        for record in self.records:
            for predecessor in record.predecessors:
                if predecessor not in self.by_id:
                    errors.append(f"Record {record.id} references unknown predecessor {predecessor}")

        route_kinds: dict[str, int] = {kind: 0 for kind in ALL_ROUTE_KINDS}
        pair_content: dict[tuple[str, str], set[str]] = defaultdict(set)
        for route in self.routes:
            if route.source not in self.by_id:
                errors.append(f"Route {route.id} has unknown source {route.source}")
                continue
            if route.target not in self.by_id:
                errors.append(f"Route {route.id} has unknown target {route.target}")
                continue
            kind = route_kind(route, self.by_id)
            route_kinds[kind] += 1
            pair_content[(route.source, route.target)].add(route.generated_content)
            declared = str(route.metadata.get("route_kind", ""))
            if declared and declared != kind:
                errors.append(f"Route {route.id} declares {declared}, but record kinds imply {kind}")

        collisions = []
        for (source, target), contents in sorted(pair_content.items()):
            if len(contents) > 1:
                collision = {
                    "source": source,
                    "target": target,
                    "generated_contents": sorted(contents),
                }
                collisions.append(collision)
                warnings.append(f"Visible route collision between {source} and {target}; it is preserved, not auto-resolved")

        for alias in self.aliases:
            for record_id in alias.record_ids:
                if record_id not in self.by_id:
                    errors.append(f"Alias {alias.id} references unknown record {record_id}")
            for predecessor in alias.predecessors:
                if predecessor == alias.id:
                    errors.append(f"Alias {alias.id} cannot be its own predecessor")

        closure = {kind.value: sum(1 for record in self.records if record.kind == kind) for kind in RecordKind}
        closure_vector = "".join("1" if closure[kind.value] > 0 else "0" for kind in RecordKind)
        open_positions = [kind for kind, count in closure.items() if count == 0]

        return {
            "state": AuditState.FAIL.value if errors else (AuditState.WARN.value if warnings else AuditState.PASS.value),
            "errors": errors,
            "warnings": warnings,
            "closure_counts": closure,
            "closure_vector": closure_vector,
            "open_positions": open_positions,
            "route_kind_counts": route_kinds,
            "observed_route_kinds": sorted(kind for kind, count in route_kinds.items() if count),
            "unobserved_but_permitted_route_kinds": sorted(kind for kind, count in route_kinds.items() if not count),
            "collisions": collisions,
            "carrier_authority": "ZERO_NATIVE_SEMANTIC_AUTHORITY",
        }

    def reachable(self, source: str, target: str) -> bool:
        if source == target:
            return True
        queue: deque[str] = deque([source])
        seen = {source}
        while queue:
            current = queue.popleft()
            for next_id in self.adjacency.get(current, []):
                if next_id == target:
                    return True
                if next_id not in seen:
                    seen.add(next_id)
                    queue.append(next_id)
        return False

    def w_to_forward_p_audit(self) -> dict[str, Any]:
        w_ids = [record.id for record in self.records if record.kind == RecordKind.W]
        forward_ps = [
            record
            for record in self.records
            if record.kind == RecordKind.P and str(record.metadata.get("direction", "forward")) == "forward"
        ]
        results: list[dict[str, Any]] = []
        for purpose in forward_ps:
            visible_from = sorted(w_id for w_id in w_ids if self.reachable(w_id, purpose.id))
            results.append(
                {
                    "purpose_id": purpose.id,
                    "visible": bool(visible_from),
                    "w_record_ids": visible_from,
                }
            )
        state = AuditState.PASS if forward_ps and all(item["visible"] for item in results) else AuditState.OPEN
        return {
            "state": state.value,
            "forward_p_count": len(forward_ps),
            "results": results,
            "rule": "Configured W must reach and affect each selected forward P.",
        }

    def p_output_audit(self) -> dict[str, Any]:
        results: list[dict[str, Any]] = []
        for purpose in (record for record in self.records if record.kind == RecordKind.P):
            output_ids = [str(item) for item in purpose.metadata.get("output_record_ids", [])]
            missing = [item for item in output_ids if item not in self.by_id]
            reachable = [item for item in output_ids if item in self.by_id and self.reachable(purpose.id, item)]
            results.append(
                {
                    "purpose_id": purpose.id,
                    "declared_outputs": output_ids,
                    "missing_outputs": missing,
                    "reachable_outputs": reachable,
                    "valid": bool(output_ids) and not missing and len(reachable) == len(output_ids),
                }
            )
        state = AuditState.PASS if results and all(item["valid"] for item in results) else AuditState.OPEN
        return {
            "state": state.value,
            "results": results,
            "rule": "A purpose does not generate an output unless an explicit P-to-output path exists.",
        }

    def roundtrip_audit(self) -> dict[str, Any]:
        records = self.by_id
        forward_ps = [
            record
            for record in self.records
            if record.kind == RecordKind.P and record.metadata.get("direction") == "forward"
        ]
        results: list[dict[str, Any]] = []
        for forward in forward_ps:
            original_outputs = [str(item) for item in forward.metadata.get("output_record_ids", [])]
            candidate_ks = [str(item) for item in forward.metadata.get("candidate_k_record_ids", [])]
            reverse_ids = [str(item) for item in forward.metadata.get("reverse_p_record_ids", [])]
            reverse_ps = [records[item] for item in reverse_ids if item in records and records[item].kind == RecordKind.P]
            regenerated_outputs: list[str] = []
            for reverse in reverse_ps:
                regenerated_outputs.extend(str(item) for item in reverse.metadata.get("output_record_ids", []))

            sameness_pairs: set[tuple[str, str]] = set()
            for record in self.records:
                if record.kind != RecordKind.D:
                    continue
                pair = record.metadata.get("same_pair")
                if isinstance(pair, list) and len(pair) == 2:
                    sameness_pairs.add((str(pair[0]), str(pair[1])))
                    sameness_pairs.add((str(pair[1]), str(pair[0])))

            matched_pairs = sorted(
                [original, regenerated]
                for original in original_outputs
                for regenerated in regenerated_outputs
                if (original, regenerated) in sameness_pairs
            )
            valid_candidates = [item for item in candidate_ks if item in records and records[item].kind == RecordKind.K]
            valid_reverse = [record.id for record in reverse_ps if record.metadata.get("direction") == "reverse"]
            valid = bool(original_outputs and valid_candidates and valid_reverse and matched_pairs)
            results.append(
                {
                    "forward_p": forward.id,
                    "original_outputs": original_outputs,
                    "candidate_k": valid_candidates,
                    "reverse_p": valid_reverse,
                    "regenerated_outputs": regenerated_outputs,
                    "d_sameness_pairs": matched_pairs,
                    "state": AuditState.PASS.value if valid else AuditState.OPEN.value,
                }
            )
        overall = AuditState.PASS if results and all(item["state"] == AuditState.PASS.value for item in results) else AuditState.OPEN
        return {
            "state": overall.value,
            "results": results,
            "minimum_roundtrip": "forward P -> candidate K -> reverse P -> regenerated output -> explicit D-sameness; residual I remains visible",
        }
