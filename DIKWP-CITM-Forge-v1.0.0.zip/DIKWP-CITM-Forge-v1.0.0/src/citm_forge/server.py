"""Local read-only static server for the offline dashboard."""

from __future__ import annotations

import functools
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path


class QuietHandler(SimpleHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:  # noqa: A002 - stdlib method signature
        print("[citm-forge] " + format % args)


def serve(directory: Path, host: str = "127.0.0.1", port: int = 8765) -> None:
    directory = directory.resolve()
    if not directory.is_dir():
        raise ValueError(f"Directory does not exist: {directory}")
    handler = functools.partial(QuietHandler, directory=str(directory))
    httpd = ThreadingHTTPServer((host, port), handler)
    print(f"Serving {directory} at http://{host}:{port}/ (Ctrl+C to stop)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopped.")
    finally:
        httpd.server_close()
