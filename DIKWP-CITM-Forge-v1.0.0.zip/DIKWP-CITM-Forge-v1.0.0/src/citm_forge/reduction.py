"""Reduction firewall: equivalence or translation is not silently promoted to proof."""

from __future__ import annotations

from typing import Any, Iterable, Mapping

from .model import ClaimState, ObligationState, ReductionContract


def audit_reduction(
    reduction: ReductionContract,
    obligation_results: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    def state(obligation_id: str) -> str:
        result = obligation_results.get(obligation_id)
        return str(result.get("state")) if result else ObligationState.OPEN.value

    soundness = state(reduction.soundness_obligation_id)
    completeness = state(reduction.completeness_obligation_id)
    target = state(reduction.target_verification_obligation_id)

    equivalence_verified = soundness == completeness == ObligationState.VERIFIED.value
    target_verified = target == ObligationState.VERIFIED.value
    if equivalence_verified and target_verified:
        claim_state = ClaimState.EQUIVALENCE_VERIFIED_WITHIN_DECLARED_SCOPE
    else:
        claim_state = ClaimState.REDUCTION_ONLY

    return {
        "reduction_id": reduction.id,
        "source_claim": reduction.source_claim,
        "target_claim": reduction.target_claim,
        "scope": reduction.scope,
        "forward_map": reduction.forward_map,
        "backward_map": reduction.backward_map,
        "soundness": {"obligation_id": reduction.soundness_obligation_id, "state": soundness},
        "completeness": {"obligation_id": reduction.completeness_obligation_id, "state": completeness},
        "target_verification": {
            "obligation_id": reduction.target_verification_obligation_id,
            "state": target,
        },
        "equivalence_verified": equivalence_verified,
        "target_verified": target_verified,
        "claim_state": claim_state.value,
        "firewall": (
            "A<->B or a problem-to-information transformation settles A only after the transformation's "
            "soundness/completeness obligations and the target claim are independently verified in the same scope."
        ),
    }


def audit_reductions(
    reductions: Iterable[ReductionContract],
    obligation_results: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any]:
    results = [audit_reduction(reduction, obligation_results) for reduction in reductions]
    if not results:
        return {"state": "NOT_APPLICABLE", "results": []}
    if all(item["claim_state"] == ClaimState.EQUIVALENCE_VERIFIED_WITHIN_DECLARED_SCOPE.value for item in results):
        state = ClaimState.EQUIVALENCE_VERIFIED_WITHIN_DECLARED_SCOPE.value
    else:
        state = ClaimState.REDUCTION_ONLY.value
    return {
        "state": state,
        "results": results,
        "global_solution_claim": "NOT_ISSUED",
        "reduction_does_not_equal_proof": True,
    }
