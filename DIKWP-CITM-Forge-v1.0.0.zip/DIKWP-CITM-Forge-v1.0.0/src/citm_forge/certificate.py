"""Construction of scope-bounded, non-sovereign certificates."""

from __future__ import annotations

from typing import Any, Mapping

from .canonical import sha256_object
from .model import AuditState, ClaimState, Project


def audit_claims(project: Project, obligation_results: Mapping[str, Mapping[str, Any]]) -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    forbidden_requested = {
        "SOLVED",
        "PROVED",
        "PROVED_GLOBALLY",
        "GLOBAL_CLOSURE",
        "FINAL_TRUTH",
        "THEOREM_SOLVED",
    }
    for index, claim in enumerate(project.claims, start=1):
        claim_id = str(claim.get("id", f"CLAIM-{index:03d}"))
        requested = str(claim.get("requested_state", "PROTOCOL_VALID")).upper()
        obligation_id = str(claim.get("obligation_id", ""))
        inherited = bool(claim.get("inherited_external_problem", False))
        if requested in forbidden_requested:
            issued = ClaimState.REFUSED_OVERCLAIM
            boundary = "The runtime does not issue global/final solution status from an internal protocol run."
        elif obligation_id:
            obligation = obligation_results.get(obligation_id, {})
            if obligation.get("state") == "VERIFIED":
                issued = ClaimState.VERIFIED_WITHIN_DECLARED_SCOPE
                boundary = str(obligation.get("scope_boundary", "Only the declared verifier scope is covered."))
            elif obligation.get("state") == "FAILED":
                issued = ClaimState.FAILED
                boundary = "The named proof obligation failed."
            elif inherited:
                issued = ClaimState.NOT_ESTABLISHED
                boundary = "The inherited external problem is not locally verified and retains its own settlement standard."
            else:
                issued = ClaimState.OPEN
                boundary = "The named proof obligation is not locally verified."
        elif inherited:
            issued = ClaimState.NOT_ESTABLISHED
            boundary = "The inherited external problem retains its own objects, quantifiers, and settlement standard."
        else:
            issued = ClaimState.PROTOCOL_VALID
            boundary = "Only protocol conformance is issued; external truth remains separately settled."
        results.append(
            {
                "id": claim_id,
                "text": str(claim.get("text", "")),
                "requested_state": requested,
                "issued_state": issued.value,
                "obligation_id": obligation_id or None,
                "boundary": boundary,
            }
        )
    return results


def build_nonaggregated_settlement(audit: Mapping[str, Any]) -> dict[str, dict[str, str]]:
    route_state = audit["native_core"]["route_audit"]["state"]
    roundtrip_state = audit["native_core"]["roundtrip"]["state"]
    world_state = audit["world_models"]["state"]
    contract_state = audit["problem_contract"]["state"]
    open_preserved = audit.get("global_closure_claim") == "NOT_ISSUED"
    return {
        "genesis": {
            "state": AuditState.PASS.value if audit["native_core"]["provenance_complete"] else AuditState.OPEN.value,
            "basis": "Record provenance is explicit" if audit["native_core"]["provenance_complete"] else "One or more records lack provenance",
        },
        "contextual_closure": {
            "state": AuditState.PASS.value if contract_state == AuditState.PASS.value and route_state != AuditState.FAIL.value else AuditState.OPEN.value,
            "basis": "Problem contract and local route graph",
        },
        "world_contact": {
            "state": AuditState.OPEN.value if world_state != AuditState.FAIL.value else AuditState.FAIL.value,
            "basis": "Probe ranking is analytical; no external action is executed",
        },
        "cross_agent_return": {
            "state": roundtrip_state,
            "basis": "Forward P, candidate K, reverse P, regenerated output, and D-sameness",
        },
        "open_position_preservation": {
            "state": AuditState.PASS.value if open_preserved else AuditState.FAIL.value,
            "basis": "Open obligations and residual I remain explicit; no global closure claim is issued",
        },
        "carrier_transduction": {
            "state": AuditState.PASS.value,
            "basis": "Canonical JSON, deterministic replay, hash chain, and machine-readable certificate",
        },
    }


def certificate_body(
    project: Project,
    audit: Mapping[str, Any],
    claim_results: list[dict[str, Any]],
    project_hash: str,
    audit_hash: str,
    pre_certificate_ledger_head: str,
) -> dict[str, Any]:
    settlement = build_nonaggregated_settlement(audit)
    return {
        "certificate_type": "DIKWP-CITM_SCOPE_BOUNDED_PROTOCOL_CERTIFICATE",
        "certificate_version": "1.0.0",
        "compiler": "DIKWP-CITM Forge 1.0.0",
        "project_id": project.project_id,
        "problem_contract_id": project.problem_contract.id,
        "problem_title": project.problem_contract.title,
        "declared_scope": project.problem_contract.scope,
        "project_hash": project_hash,
        "audit_hash": audit_hash,
        "pre_certificate_ledger_head": pre_certificate_ledger_head,
        "nonaggregated_settlement": settlement,
        "claim_results": claim_results,
        "global_closure_claim": "NOT_ISSUED",
        "external_domain_settlement": "NOT_ESTABLISHED",
        "automatic_external_action_authority": 0,
        "boundary_statement_en": (
            "This certificate establishes only what the declared finite encodings, protocol checks, and verifiers establish. "
            "A reduction is not a proof; a finite witness table is not an unrestricted theorem; software conformance is not "
            "external mathematical acceptance; synthetic execution is not empirical reality contact."
        ),
        "boundary_statement_cn": (
            "本证书只确认声明的有限编码、协议检查和验证器实际确认的内容。问题还原不等于证明，有限见证表不等于无界全称定理，"
            "软件符合规格不等于外部数学共同体结算，合成执行不等于现实经验接触。"
        ),
    }


def finalise_certificate(body: Mapping[str, Any], final_ledger_head: str, ledger_event_count: int) -> dict[str, Any]:
    body_hash = sha256_object(body)
    run_hash = sha256_object(
        {
            "project_hash": body["project_hash"],
            "audit_hash": body["audit_hash"],
            "certificate_body_hash": body_hash,
            "final_ledger_head": final_ledger_head,
            "compiler": body["compiler"],
        }
    )
    return {
        **dict(body),
        "certificate_body_hash": body_hash,
        "ledger_head_hash": final_ledger_head,
        "ledger_event_count": ledger_event_count,
        "run_hash": run_hash,
    }
