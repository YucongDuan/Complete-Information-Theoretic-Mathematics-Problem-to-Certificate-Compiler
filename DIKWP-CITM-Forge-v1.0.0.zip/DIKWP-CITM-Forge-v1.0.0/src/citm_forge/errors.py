"""Typed errors used by DIKWP-CITM Forge."""

from __future__ import annotations


class ForgeError(Exception):
    """Base exception for the project."""


class ValidationError(ForgeError):
    """Raised when a project violates a hard protocol invariant."""


class IntegrityError(ForgeError):
    """Raised when a hash chain, manifest, or certificate is inconsistent."""


class UnsafeInputError(ForgeError):
    """Raised when an input requests unsupported or unsafe execution."""
