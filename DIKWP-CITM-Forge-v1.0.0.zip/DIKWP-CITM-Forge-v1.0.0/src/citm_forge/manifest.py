"""Release/output manifests and Merkle roots."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Iterable

from .canonical import sha256_file, sha256_text
from .errors import IntegrityError


DEFAULT_EXCLUDES = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
    ".DS_Store",
}


def merkle_root(hex_hashes: Iterable[str]) -> str:
    level = [str(item) for item in hex_hashes]
    if not level:
        return sha256_text("")
    while len(level) > 1:
        if len(level) % 2 == 1:
            level.append(level[-1])
        next_level: list[str] = []
        for index in range(0, len(level), 2):
            next_level.append(sha256_text(level[index] + level[index + 1]))
        level = next_level
    return level[0]


def build_manifest(
    root: Path,
    *,
    excluded_paths: Iterable[str] = (),
    excluded_names: Iterable[str] = DEFAULT_EXCLUDES,
) -> dict[str, Any]:
    root = root.resolve()
    excluded_path_set = {str(Path(item).as_posix()) for item in excluded_paths}
    excluded_name_set = set(excluded_names)
    files: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(root).as_posix()
        if relative in excluded_path_set:
            continue
        if any(part in excluded_name_set for part in path.relative_to(root).parts):
            continue
        files.append(
            {
                "path": relative,
                "size_bytes": path.stat().st_size,
                "sha256": sha256_file(path),
            }
        )
    return {
        "root_name": root.name,
        "file_count": len(files),
        "total_size_bytes": sum(item["size_bytes"] for item in files),
        "merkle_root": merkle_root(item["sha256"] for item in files),
        "files": files,
    }


def verify_manifest(root: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    root = root.resolve()
    errors: list[str] = []
    calculated_hashes: list[str] = []
    for item in manifest.get("files", []):
        relative = str(item.get("path", ""))
        candidate = (root / relative).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            errors.append(f"Manifest path escapes root: {relative}")
            continue
        if not candidate.is_file():
            errors.append(f"Missing file: {relative}")
            continue
        actual = sha256_file(candidate)
        calculated_hashes.append(actual)
        if actual != item.get("sha256"):
            errors.append(f"Hash mismatch: {relative}")
        if candidate.stat().st_size != int(item.get("size_bytes", -1)):
            errors.append(f"Size mismatch: {relative}")
    calculated_root = merkle_root(calculated_hashes)
    if calculated_root != manifest.get("merkle_root"):
        errors.append("Merkle root mismatch")
    if errors:
        raise IntegrityError("; ".join(errors))
    return {
        "valid": True,
        "file_count": len(calculated_hashes),
        "merkle_root": calculated_root,
    }
