"""Command-line interface."""

from __future__ import annotations

import argparse
import importlib.resources
import json
import sys
from pathlib import Path

from . import __version__
from .compiler import ForgeCompiler
from .errors import ForgeError, IntegrityError
from .io import load_json
from .ledger import HashChainLedger
from .manifest import verify_manifest
from .server import serve


def _load_reference_project() -> dict:
    resource = importlib.resources.files("citm_forge.data").joinpath("reference_project.json")
    return json.loads(resource.read_text(encoding="utf-8"))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="citm-forge",
        description=(
            "Compile a declarative DIKWP/CITM mathematical problem into a scope-bounded, "
            "hash-linked, replayable certificate without silently claiming global proof."
        ),
    )
    parser.add_argument("--version", action="version", version=f"DIKWP-CITM Forge {__version__}")
    subparsers = parser.add_subparsers(dest="command", required=True)

    compile_parser = subparsers.add_parser("compile", help="Compile a project JSON")
    compile_parser.add_argument("project", type=Path)
    compile_parser.add_argument("--output", "-o", type=Path, required=True)

    demo_parser = subparsers.add_parser("demo", help="Compile the bundled reference project")
    demo_parser.add_argument("--output", "-o", type=Path, default=Path("outputs/demo"))

    ledger_parser = subparsers.add_parser("verify-ledger", help="Verify a JSONL hash chain")
    ledger_parser.add_argument("ledger", type=Path)

    manifest_parser = subparsers.add_parser("verify-manifest", help="Verify a release/output manifest")
    manifest_parser.add_argument("root", type=Path)
    manifest_parser.add_argument("manifest", type=Path)

    serve_parser = subparsers.add_parser("serve", help="Serve a local static dashboard")
    serve_parser.add_argument("directory", type=Path, nargs="?", default=Path("web"))
    serve_parser.add_argument("--host", default="127.0.0.1")
    serve_parser.add_argument("--port", type=int, default=8765)

    status_parser = subparsers.add_parser("show-status", help="Print key certificate states")
    status_parser.add_argument("certificate", type=Path)
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.command == "compile":
            raw = load_json(args.project)
            result = ForgeCompiler().compile(raw, args.output)
            print(json.dumps(result.certificate, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        if args.command == "demo":
            raw = _load_reference_project()
            result = ForgeCompiler().compile(raw, args.output)
            print(f"Demo compiled: {result.output_directory}")
            print(f"Run hash: {result.certificate['run_hash']}")
            print("Global closure claim: NOT_ISSUED")
            return 0
        if args.command == "verify-ledger":
            ledger = HashChainLedger.read(args.ledger)
            print(json.dumps(ledger.verify(), indent=2, sort_keys=True))
            return 0
        if args.command == "verify-manifest":
            manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
            print(json.dumps(verify_manifest(args.root, manifest), indent=2, sort_keys=True))
            return 0
        if args.command == "serve":
            serve(args.directory, args.host, args.port)
            return 0
        if args.command == "show-status":
            certificate = json.loads(args.certificate.read_text(encoding="utf-8"))
            print(f"project_id={certificate['project_id']}")
            print(f"run_hash={certificate['run_hash']}")
            print(f"global_closure_claim={certificate['global_closure_claim']}")
            print(f"external_domain_settlement={certificate['external_domain_settlement']}")
            for key, item in certificate["nonaggregated_settlement"].items():
                print(f"{key}={item['state']}")
            return 0
    except (ForgeError, IntegrityError, ValueError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 1
