"""Problem-contract and quantifier audits."""

from __future__ import annotations

from typing import Any

from .model import AuditState, ProblemContract


EIGHT_DIMENSIONS = (
    "objects",
    "scope",
    "quantifiers",
    "operations",
    "environment",
    "terminal_condition",
    "concept_return",
    "version_migration",
)


def audit_problem_contract(contract: ProblemContract) -> dict[str, Any]:
    dimensions: dict[str, dict[str, Any]] = {}
    for name in EIGHT_DIMENSIONS:
        value = getattr(contract, name)
        present = bool(value)
        dimensions[name] = {
            "state": AuditState.PASS.value if present else AuditState.FAIL.value,
            "value": list(value) if isinstance(value, tuple) else value,
        }

    prohibited = list(contract.prohibited_inferences)
    reopen = list(contract.reopening_conditions)
    state = AuditState.PASS if all(item["state"] == AuditState.PASS.value for item in dimensions.values()) else AuditState.FAIL
    warnings: list[str] = []
    if not prohibited:
        warnings.append("No prohibited inference is registered; overclaim boundaries are underspecified.")
    if not reopen:
        warnings.append("No reopening condition is registered; revision/retirement is underspecified.")
    if not contract.inherited_standard:
        warnings.append("No inherited external standard is named; external settlement remains NOT_ESTABLISHED.")

    return {
        "state": state.value,
        "dimensions": dimensions,
        "prohibited_inferences": prohibited,
        "reopening_conditions": reopen,
        "inherited_standard": contract.inherited_standard,
        "warnings": warnings,
    }


def audit_quantifiers(contract: ProblemContract) -> dict[str, Any]:
    text = " ".join(contract.quantifiers).lower()
    universal_tokens = ("for all", "forall", "∀", "every", "all ", "任意", "所有", "每个")
    existential_tokens = ("there exists", "exists", "∃", "some ", "存在")
    has_universal = any(token in text for token in universal_tokens)
    has_existential = any(token in text for token in existential_tokens)
    scope_text = contract.scope.lower()
    finite_scope = any(token in scope_text for token in ("finite", "bounded", "range", "有限", "范围"))
    unrestricted_scope = any(token in scope_text for token in ("unrestricted", "global", "all", "全称", "无界", "全部"))

    warnings: list[str] = []
    if has_universal and finite_scope:
        warnings.append(
            "Universal wording appears with a finite/bounded scope. The certificate is restricted to the declared domain."
        )
    if unrestricted_scope and not has_universal:
        warnings.append("The scope appears unrestricted but no explicit universal quantifier was detected.")

    return {
        "state": AuditState.WARN.value if warnings else AuditState.PASS.value,
        "has_universal": has_universal,
        "has_existential": has_existential,
        "finite_scope": finite_scope,
        "unrestricted_scope": unrestricted_scope,
        "quantifiers": list(contract.quantifiers),
        "warnings": warnings,
    }
