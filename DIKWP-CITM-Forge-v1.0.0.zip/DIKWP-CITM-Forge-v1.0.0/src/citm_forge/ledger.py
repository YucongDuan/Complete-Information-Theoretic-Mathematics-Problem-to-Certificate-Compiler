"""Append-only deterministic event ledger with a SHA-256 hash chain."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping

from .canonical import canonical_json, sha256_object
from .errors import IntegrityError


GENESIS_HASH = "0" * 64


@dataclass(frozen=True)
class LedgerEvent:
    sequence: int
    stage: str
    event_type: str
    payload: Mapping[str, Any]
    previous_hash: str
    event_hash: str

    def to_dict(self) -> dict[str, Any]:
        return {
            "sequence": self.sequence,
            "stage": self.stage,
            "event_type": self.event_type,
            "payload": dict(self.payload),
            "previous_hash": self.previous_hash,
            "event_hash": self.event_hash,
        }


class HashChainLedger:
    """A deterministic append-only ledger.

    No wall-clock timestamp is included in a ledger event. Reproducibility is
    prioritised: the same project and compiler version yield the same chain.
    Release metadata may separately include a human-readable build time.
    """

    def __init__(self) -> None:
        self._events: list[LedgerEvent] = []

    @property
    def events(self) -> tuple[LedgerEvent, ...]:
        return tuple(self._events)

    @property
    def head_hash(self) -> str:
        return self._events[-1].event_hash if self._events else GENESIS_HASH

    def append(self, stage: str, event_type: str, payload: Mapping[str, Any]) -> LedgerEvent:
        sequence = len(self._events) + 1
        previous_hash = self.head_hash
        body = {
            "sequence": sequence,
            "stage": str(stage),
            "event_type": str(event_type),
            "payload": dict(payload),
            "previous_hash": previous_hash,
        }
        event = LedgerEvent(
            sequence=sequence,
            stage=str(stage),
            event_type=str(event_type),
            payload=dict(payload),
            previous_hash=previous_hash,
            event_hash=sha256_object(body),
        )
        self._events.append(event)
        return event

    def to_jsonl(self) -> str:
        return "".join(canonical_json(event.to_dict()) + "\n" for event in self._events)

    def write(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(self.to_jsonl(), encoding="utf-8")

    @classmethod
    def from_jsonl(cls, text: str) -> "HashChainLedger":
        ledger = cls()
        parsed: list[dict[str, Any]] = []
        for line_number, line in enumerate(text.splitlines(), start=1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                raise IntegrityError(f"Invalid JSON at ledger line {line_number}") from exc
            parsed.append(item)
        cls.verify_dicts(parsed)
        for item in parsed:
            ledger._events.append(
                LedgerEvent(
                    sequence=int(item["sequence"]),
                    stage=str(item["stage"]),
                    event_type=str(item["event_type"]),
                    payload=dict(item["payload"]),
                    previous_hash=str(item["previous_hash"]),
                    event_hash=str(item["event_hash"]),
                )
            )
        return ledger

    @classmethod
    def read(cls, path: Path) -> "HashChainLedger":
        return cls.from_jsonl(path.read_text(encoding="utf-8"))

    @staticmethod
    def verify_dicts(events: Iterable[Mapping[str, Any]]) -> dict[str, Any]:
        expected_previous = GENESIS_HASH
        count = 0
        for count, item in enumerate(events, start=1):
            required = {
                "sequence",
                "stage",
                "event_type",
                "payload",
                "previous_hash",
                "event_hash",
            }
            missing = required.difference(item)
            if missing:
                raise IntegrityError(f"Ledger event {count} missing {sorted(missing)}")
            if int(item["sequence"]) != count:
                raise IntegrityError(f"Ledger sequence mismatch at event {count}")
            if str(item["previous_hash"]) != expected_previous:
                raise IntegrityError(f"Ledger previous hash mismatch at event {count}")
            body = {
                "sequence": count,
                "stage": str(item["stage"]),
                "event_type": str(item["event_type"]),
                "payload": dict(item["payload"]),
                "previous_hash": expected_previous,
            }
            calculated = sha256_object(body)
            if str(item["event_hash"]) != calculated:
                raise IntegrityError(f"Ledger event hash mismatch at event {count}")
            expected_previous = calculated
        return {"valid": True, "event_count": count, "head_hash": expected_previous}

    def verify(self) -> dict[str, Any]:
        return self.verify_dicts(event.to_dict() for event in self._events)
