"""Nine-stage DIKWP-CITM problem-to-certificate compiler."""

from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from .canonical import pretty_json, sha256_object, to_primitive, write_json
from .certificate import audit_claims, certificate_body, finalise_certificate
from .contracts import audit_problem_contract, audit_quantifiers
from .information import audit_information_contract
from .io import safe_output_directory
from .ledger import HashChainLedger
from .manifest import build_manifest
from .model import AuditState, Project
from .quotient import future_effect_quotient
from .reduction import audit_reductions
from .report import render_report
from .routes import RouteAudit
from .verifier import verify_all
from .worlds import audit_world_models


PIPELINE = (
    ("S1_NORMALISE_SPEC", "Normalised specification / 规范化规格"),
    ("S2_CLAIM_REPLAY", "Claim replay / 主张重放"),
    ("S3_CARRIER_AUDIT", "Carrier audit / 载体审计"),
    ("S4_PATTERN_AUDIT", "Pattern and route audit / 母式与路径审计"),
    ("S5_SEMANTIC_DECOMPRESSION", "Semantic decompression / 语义解压"),
    ("S6_QUANTIFIER_AUDIT", "Quantifier audit / 量词审计"),
    ("S7_EIGHT_DIMENSION_BRIDGE", "Eight-dimensional bridge / 八维桥接"),
    ("S8_MAX_PERSISTENT_CORE", "Maximum persistent core / 最大持续核心"),
    ("S9_NONAGGREGATED_SETTLEMENT", "Non-aggregated settlement / 非聚合结算"),
)


@dataclass(frozen=True)
class CompileResult:
    output_directory: Path
    certificate: Mapping[str, Any]
    audit: Mapping[str, Any]
    manifest: Mapping[str, Any]


class ForgeCompiler:
    """Compile a declarative project into deterministic audit artefacts."""

    VERSION = "1.0.0"

    def compile(self, raw_project: Mapping[str, Any] | Project, output_directory: Path) -> CompileResult:
        output = safe_output_directory(output_directory)
        if any(output.iterdir()):
            # Preserve explicit user files unless this directory is a prior Forge output.
            known = {
                "normalized_project.json",
                "audit.json",
                "certificate.json",
                "ledger.jsonl",
                "audit_report.md",
                "dashboard_data.json",
                "output_manifest.json",
            }
            unknown = [item.name for item in output.iterdir() if item.name not in known]
            if unknown:
                raise ValueError(
                    "Output directory is not empty and contains non-Forge files: " + ", ".join(sorted(unknown))
                )
            for item in list(output.iterdir()):
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()

        project = raw_project if isinstance(raw_project, Project) else Project.from_dict(raw_project)
        normalized = to_primitive(project)
        project_hash = sha256_object(normalized)
        ledger = HashChainLedger()
        pipeline_results: list[dict[str, Any]] = []

        # S1 — Normalised specification.
        contract_audit = audit_problem_contract(project.problem_contract)
        stage_state = contract_audit["state"]
        ledger.append(
            PIPELINE[0][0],
            "SPEC_NORMALISED",
            {
                "project_id": project.project_id,
                "project_hash": project_hash,
                "contract_state": stage_state,
                "compiler_version": self.VERSION,
            },
        )
        pipeline_results.append({"id": PIPELINE[0][0], "name": PIPELINE[0][1], "state": stage_state})

        # Proof obligations are evaluated early so claim replay can bind them.
        obligation_audit = verify_all(project.proof_obligations)
        obligation_results = obligation_audit["results"]

        # S2 — Claim replay and overclaim firewall.
        claim_results = audit_claims(project, obligation_results)
        claim_state = (
            AuditState.FAIL.value
            if any(item["issued_state"] == "FAILED" for item in claim_results)
            else (
                AuditState.WARN.value
                if any(item["issued_state"] in {"REFUSED_OVERCLAIM", "OPEN", "NOT_ESTABLISHED"} for item in claim_results)
                else AuditState.PASS.value
            )
        )
        ledger.append(
            PIPELINE[1][0],
            "CLAIMS_REPLAYED",
            {
                "claim_count": len(claim_results),
                "states": {item["id"]: item["issued_state"] for item in claim_results},
            },
        )
        pipeline_results.append({"id": PIPELINE[1][0], "name": PIPELINE[1][1], "state": claim_state})

        # S3/S4/S5 — Carrier, route, and semantic audits.
        route_engine = RouteAudit(project.records, project.routes, project.aliases)
        route_audit = route_engine.validate()
        provenance_missing = [record.id for record in project.records if not record.provenance]
        carrier_audit = {
            "state": AuditState.WARN.value if provenance_missing else AuditState.PASS.value,
            "record_count": len(project.records),
            "route_count": len(project.routes),
            "alias_count": len(project.aliases),
            "records_without_provenance": provenance_missing,
            "alias_authority": "ZERO_NATIVE_SEMANTIC_AUTHORITY",
            "boundary": "Aliases and carriers may transport records but cannot supply missing D/I/K/W/P content.",
        }
        ledger.append(
            PIPELINE[2][0],
            "CARRIERS_AUDITED",
            {
                "record_count": len(project.records),
                "alias_count": len(project.aliases),
                "provenance_missing": provenance_missing,
            },
        )
        pipeline_results.append(
            {"id": PIPELINE[2][0], "name": PIPELINE[2][1], "state": carrier_audit["state"]}
        )

        ledger.append(
            PIPELINE[3][0],
            "ROUTES_AUDITED",
            {
                "state": route_audit["state"],
                "closure_vector": route_audit["closure_vector"],
                "collision_count": len(route_audit["collisions"]),
                "observed_route_kind_count": len(route_audit["observed_route_kinds"]),
            },
        )
        pipeline_results.append(
            {"id": PIPELINE[3][0], "name": PIPELINE[3][1], "state": route_audit["state"]}
        )

        w_to_p = route_engine.w_to_forward_p_audit()
        p_outputs = route_engine.p_output_audit()
        roundtrip = route_engine.roundtrip_audit()
        semantic_state = (
            AuditState.PASS.value
            if all(item["state"] == AuditState.PASS.value for item in (w_to_p, p_outputs, roundtrip))
            else AuditState.OPEN.value
        )
        ledger.append(
            PIPELINE[4][0],
            "SEMANTICS_DECOMPRESSED",
            {
                "w_to_p": w_to_p["state"],
                "p_outputs": p_outputs["state"],
                "roundtrip": roundtrip["state"],
                "open_positions": route_audit["open_positions"],
            },
        )
        pipeline_results.append({"id": PIPELINE[4][0], "name": PIPELINE[4][1], "state": semantic_state})

        # S6 — Quantifier audit, information theory, finite quotient, proof obligations.
        quantifier_audit = audit_quantifiers(project.problem_contract)
        information_audit = audit_information_contract(project.information_contract)
        quotient_audit = future_effect_quotient(project.future_effect_system)
        quantifier_stage_state = (
            AuditState.FAIL.value
            if quantifier_audit["state"] == AuditState.FAIL.value
            or information_audit["state"] == AuditState.FAIL.value
            or quotient_audit["state"] == AuditState.FAIL.value
            or obligation_audit["state"] == "FAILED"
            else (
                AuditState.WARN.value
                if quantifier_audit["state"] == AuditState.WARN.value
                or information_audit["state"] == AuditState.WARN.value
                or obligation_audit["state"] == "OPEN"
                else AuditState.PASS.value
            )
        )
        ledger.append(
            PIPELINE[5][0],
            "QUANTIFIERS_AND_FINITE_VERIFIERS_AUDITED",
            {
                "quantifier_state": quantifier_audit["state"],
                "information_state": information_audit["state"],
                "quotient_state": quotient_audit["state"],
                "proof_obligation_state": obligation_audit["state"],
            },
        )
        pipeline_results.append(
            {"id": PIPELINE[5][0], "name": PIPELINE[5][1], "state": quantifier_stage_state}
        )

        # S7 — Eight-dimensional bridge and plural world models.
        world_audit = audit_world_models(project.world_models, project.probes, project.impact_level)
        bridge_state = (
            AuditState.FAIL.value
            if contract_audit["state"] == AuditState.FAIL.value or world_audit["state"] == AuditState.FAIL.value
            else (AuditState.WARN.value if world_audit["state"] == AuditState.WARN.value else AuditState.PASS.value)
        )
        ledger.append(
            PIPELINE[6][0],
            "EIGHT_DIMENSION_BRIDGE_AUDITED",
            {
                "contract_state": contract_audit["state"],
                "world_model_state": world_audit["state"],
                "distinct_world_structures": world_audit["distinct_structure_count"],
                "automatic_external_action_authority": 0,
            },
        )
        pipeline_results.append({"id": PIPELINE[6][0], "name": PIPELINE[6][1], "state": bridge_state})

        # Reduction firewall after obligations.
        reductions_audit = audit_reductions(project.reductions, obligation_results)

        # S8 — Maximum persistent core.
        persistent_core: list[dict[str, Any]] = []
        if contract_audit["state"] == AuditState.PASS.value:
            persistent_core.append({"id": "problem_contract", "state": "PERSIST", "reason": "all eight dimensions supplied"})
        if route_audit["state"] != AuditState.FAIL.value:
            persistent_core.append({"id": "record_route_graph", "state": "PERSIST", "reason": "record ids and explicit routes are replayable"})
        if information_audit["state"] == AuditState.PASS.value:
            persistent_core.append({"id": "finite_information_results", "state": "PERSIST_WITHIN_SCOPE", "reason": "finite tables pass encoded checks"})
        if quotient_audit["state"] == AuditState.PASS.value:
            persistent_core.append({"id": "future_effect_quotient", "state": "PERSIST_WITHIN_SCOPE", "reason": "coarsest finite quotient recomputed"})
        for obligation_id, result in sorted(obligation_results.items()):
            if result["state"] == "VERIFIED":
                persistent_core.append(
                    {"id": f"obligation:{obligation_id}", "state": "PERSIST_WITHIN_SCOPE", "reason": result.get("scope_boundary", "verified")}
                )
        open_obligations = [
            {"id": obligation_id, "state": result["state"], "claim": result["claim"]}
            for obligation_id, result in sorted(obligation_results.items())
            if result["state"] != "VERIFIED"
        ]
        ledger.append(
            PIPELINE[7][0],
            "MAXIMUM_PERSISTENT_CORE_EXTRACTED",
            {
                "persistent_item_count": len(persistent_core),
                "open_obligation_count": len(open_obligations),
            },
        )
        persistent_state = AuditState.PASS.value if persistent_core else AuditState.OPEN.value
        pipeline_results.append({"id": PIPELINE[7][0], "name": PIPELINE[7][1], "state": persistent_state})

        # Register the ninth stage before freezing the audit object. The subsequent
        # ledger event commits the resulting certificate-body hash.
        pipeline_results.append({"id": PIPELINE[8][0], "name": PIPELINE[8][1], "state": AuditState.PASS.value})

        audit: dict[str, Any] = {
            "compiler": {"name": "DIKWP-CITM Forge", "version": self.VERSION},
            "project_id": project.project_id,
            "project_hash": project_hash,
            "pipeline": pipeline_results,
            "problem_contract": contract_audit,
            "quantifiers": quantifier_audit,
            "carrier_audit": carrier_audit,
            "native_core": {
                "provenance_complete": not provenance_missing,
                "route_audit": route_audit,
                "w_to_p_visibility": w_to_p,
                "p_output_paths": p_outputs,
                "roundtrip": roundtrip,
            },
            "information_theory": information_audit,
            "future_effect_quotient": quotient_audit,
            "world_models": world_audit,
            "proof_obligations": obligation_audit,
            "reductions": reductions_audit,
            "persistent_core": persistent_core,
            "open_obligations": open_obligations,
            "global_closure_claim": "NOT_ISSUED",
            "external_domain_settlement": "NOT_ESTABLISHED",
        }

        # S9 — Non-aggregated settlement is encoded into a frozen certificate body.
        audit_hash = sha256_object(audit)
        pre_certificate_head = ledger.head_hash
        body = certificate_body(
            project,
            audit,
            claim_results,
            project_hash,
            audit_hash,
            pre_certificate_head,
        )
        body_hash = sha256_object(body)
        ledger.append(
            PIPELINE[8][0],
            "SCOPE_BOUNDED_CERTIFICATE_BODY_ISSUED",
            {
                "certificate_body_hash": body_hash,
                "global_closure_claim": "NOT_ISSUED",
                "external_domain_settlement": "NOT_ESTABLISHED",
            },
        )
        certificate = finalise_certificate(body, ledger.head_hash, len(ledger.events))

        write_json(output / "normalized_project.json", normalized)
        write_json(output / "audit.json", audit)
        write_json(output / "certificate.json", certificate)
        ledger.write(output / "ledger.jsonl")
        (output / "audit_report.md").write_text(render_report(certificate, audit), encoding="utf-8")
        write_json(
            output / "dashboard_data.json",
            {
                "project": {
                    "id": project.project_id,
                    "title": project.problem_contract.title,
                    "scope": project.problem_contract.scope,
                },
                "certificate": certificate,
                "audit": audit,
            },
        )
        manifest = build_manifest(output, excluded_paths={"output_manifest.json"})
        write_json(output / "output_manifest.json", manifest)
        return CompileResult(output, certificate, audit, manifest)
