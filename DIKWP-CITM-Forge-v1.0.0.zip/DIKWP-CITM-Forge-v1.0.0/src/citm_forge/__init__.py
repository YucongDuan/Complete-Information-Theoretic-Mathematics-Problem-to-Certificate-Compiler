"""DIKWP-CITM Forge.

A dependency-free reference implementation of a problem-to-certificate compiler
for Complete Information-Theoretic Mathematics (CITM) under DIKWP-MESH 9.2.

The package deliberately distinguishes protocol-valid internal certificates from
external mathematical settlement. It never treats a reduction, finite check,
semantic reconstruction, or successful demo as a global proof by itself.
"""

from .compiler import ForgeCompiler, CompileResult
from .model import (
    AuditState,
    ClaimState,
    ImpactLevel,
    ObligationState,
    Project,
    RecordKind,
)

__all__ = [
    "AuditState",
    "ClaimState",
    "CompileResult",
    "ForgeCompiler",
    "ImpactLevel",
    "ObligationState",
    "Project",
    "RecordKind",
]

__version__ = "1.0.0"
