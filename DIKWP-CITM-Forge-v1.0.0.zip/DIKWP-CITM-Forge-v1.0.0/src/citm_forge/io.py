"""Bounded local file I/O helpers."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Mapping

from .errors import UnsafeInputError, ValidationError


DEFAULT_MAX_JSON_BYTES = 10 * 1024 * 1024


def load_json(path: Path, *, max_bytes: int = DEFAULT_MAX_JSON_BYTES) -> Mapping[str, Any]:
    path = path.resolve()
    if not path.is_file():
        raise ValidationError(f"Input file does not exist: {path}")
    size = path.stat().st_size
    if size > max_bytes:
        raise UnsafeInputError(f"JSON input exceeds {max_bytes} bytes: {size}")
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationError(f"Invalid UTF-8 JSON: {path}") from exc
    if not isinstance(raw, Mapping):
        raise ValidationError("Project root must be a JSON object")
    return raw


def safe_output_directory(path: Path) -> Path:
    resolved = path.resolve()
    if resolved == Path(resolved.anchor):
        raise UnsafeInputError("Refusing to use a filesystem root as output directory")
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved
