"""Finite future-effect equivalence quotient and refinement audit."""

from __future__ import annotations

from collections import defaultdict
from typing import Any, Mapping

from .canonical import canonical_json
from .model import AuditState


def _effect_key(history: str, continuation: str) -> str:
    return f"{history}|{continuation}"


def future_effect_quotient(system: Mapping[str, Any]) -> dict[str, Any]:
    if not system:
        return {"state": AuditState.NOT_APPLICABLE.value, "reason": "No future-effect system supplied"}
    histories = [str(item) for item in system.get("histories", [])]
    continuations = [str(item) for item in system.get("continuations", [])]
    effects = dict(system.get("effects", {}))
    if not histories or not continuations:
        return {"state": AuditState.FAIL.value, "errors": ["histories and continuations must be non-empty"]}

    errors: list[str] = []
    signatures: dict[str, tuple[str, ...]] = {}
    for history in histories:
        signature: list[str] = []
        for continuation in continuations:
            key = _effect_key(history, continuation)
            if key not in effects:
                errors.append(f"Missing effect for {key}")
                signature.append("__MISSING__")
            else:
                signature.append(canonical_json(effects[key]))
        signatures[history] = tuple(signature)

    groups_by_signature: defaultdict[tuple[str, ...], list[str]] = defaultdict(list)
    for history, signature in signatures.items():
        groups_by_signature[signature].append(history)
    groups = [sorted(group) for _, group in sorted(groups_by_signature.items(), key=lambda item: item[1][0])]

    result: dict[str, Any] = {
        "state": AuditState.FAIL.value if errors else AuditState.PASS.value,
        "histories": histories,
        "continuations": continuations,
        "signatures": {key: list(value) for key, value in signatures.items()},
        "quotient_classes": groups,
        "class_count": len(groups),
        "errors": errors,
        "coarsest_lossless_within_declared_continuations": not errors,
        "boundary": "The quotient is exact only for the explicitly admitted finite continuation family.",
    }

    refinement = system.get("refinement")
    if isinstance(refinement, Mapping):
        refined_input = {
            "histories": histories,
            "continuations": continuations + [str(item) for item in refinement.get("continuations", [])],
            "effects": {**effects, **dict(refinement.get("effects", {}))},
        }
        refined = future_effect_quotient(refined_input)
        old_class_of = {member: index for index, group in enumerate(groups) for member in group}
        new_groups = refined.get("quotient_classes", [])
        refinement_valid = True
        for group in new_groups:
            if len({old_class_of[member] for member in group}) > 1:
                refinement_valid = False
        result["refinement"] = {
            "new_continuations": list(refinement.get("continuations", [])),
            "new_quotient_classes": new_groups,
            "old_class_count": len(groups),
            "new_class_count": len(new_groups),
            "monotone_refinement": refinement_valid and len(new_groups) >= len(groups),
        }
    return result
