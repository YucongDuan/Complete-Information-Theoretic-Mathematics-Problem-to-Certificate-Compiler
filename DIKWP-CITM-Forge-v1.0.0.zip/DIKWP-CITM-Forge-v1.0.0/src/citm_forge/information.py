"""Finite, exact-enough information-theory utilities for auditable examples.

All routines are intentionally limited to explicitly enumerated finite spaces.
They do not infer that an empirical semantic or physical system is exhausted by
its encoded probability table.
"""

from __future__ import annotations

import math
from collections import defaultdict
from typing import Any, Mapping

from .model import AuditState


TOLERANCE = 1e-9


def validate_distribution(distribution: Mapping[str, float], *, tolerance: float = TOLERANCE) -> None:
    if not distribution:
        raise ValueError("Probability distribution must not be empty")
    values = [float(value) for value in distribution.values()]
    if any(value < -tolerance for value in values):
        raise ValueError("Probability values must be non-negative")
    if abs(sum(values) - 1.0) > tolerance:
        raise ValueError(f"Probability values must sum to 1, got {sum(values)!r}")


def entropy(distribution: Mapping[str, float], base: float = 2.0) -> float:
    validate_distribution(distribution)
    return -sum(float(probability) * math.log(float(probability), base) for probability in distribution.values() if probability > 0)


def channel_output_distribution(
    source: Mapping[str, float], channel: Mapping[str, Mapping[str, float]]
) -> dict[str, float]:
    validate_distribution(source)
    output: defaultdict[str, float] = defaultdict(float)
    for state, probability in source.items():
        if state not in channel:
            raise ValueError(f"Channel has no row for source state {state}")
        validate_distribution(channel[state])
        for outcome, conditional in channel[state].items():
            output[outcome] += float(probability) * float(conditional)
    result = dict(sorted(output.items()))
    validate_distribution(result)
    return result


def joint_from_source_channel(
    source: Mapping[str, float], channel: Mapping[str, Mapping[str, float]]
) -> dict[tuple[str, str], float]:
    validate_distribution(source)
    joint: dict[tuple[str, str], float] = {}
    for state, probability in source.items():
        if state not in channel:
            raise ValueError(f"Channel has no row for source state {state}")
        validate_distribution(channel[state])
        for outcome, conditional in channel[state].items():
            joint[(state, outcome)] = float(probability) * float(conditional)
    return joint


def mutual_information(
    source: Mapping[str, float], channel: Mapping[str, Mapping[str, float]], base: float = 2.0
) -> float:
    joint = joint_from_source_channel(source, channel)
    output = channel_output_distribution(source, channel)
    total = 0.0
    for (state, outcome), probability in joint.items():
        if probability <= 0:
            continue
        denominator = float(source[state]) * float(output[outcome])
        total += probability * math.log(probability / denominator, base)
    return total


def compose_channels(
    first: Mapping[str, Mapping[str, float]], second: Mapping[str, Mapping[str, float]]
) -> dict[str, dict[str, float]]:
    result: dict[str, dict[str, float]] = {}
    for source_state, middle_distribution in first.items():
        validate_distribution(middle_distribution)
        output: defaultdict[str, float] = defaultdict(float)
        for middle_state, first_probability in middle_distribution.items():
            if middle_state not in second:
                raise ValueError(f"Second channel has no row for intermediate state {middle_state}")
            validate_distribution(second[middle_state])
            for output_state, second_probability in second[middle_state].items():
                output[output_state] += float(first_probability) * float(second_probability)
        result[source_state] = dict(sorted(output.items()))
        validate_distribution(result[source_state])
    return result


def total_variation(left: Mapping[str, float], right: Mapping[str, float]) -> float:
    keys = set(left) | set(right)
    return 0.5 * sum(abs(float(left.get(key, 0.0)) - float(right.get(key, 0.0))) for key in keys)


def kl_divergence(left: Mapping[str, float], right: Mapping[str, float], base: float = 2.0) -> float:
    validate_distribution(left)
    validate_distribution(right)
    total = 0.0
    for key, probability in left.items():
        p = float(probability)
        q = float(right.get(key, 0.0))
        if p == 0:
            continue
        if q <= 0:
            return math.inf
        total += p * math.log(p / q, base)
    return total


def jensen_shannon(left: Mapping[str, float], right: Mapping[str, float], base: float = 2.0) -> float:
    validate_distribution(left)
    validate_distribution(right)
    keys = sorted(set(left) | set(right))
    left_complete = {key: float(left.get(key, 0.0)) for key in keys}
    right_complete = {key: float(right.get(key, 0.0)) for key in keys}
    midpoint = {key: 0.5 * (left_complete[key] + right_complete[key]) for key in keys}
    return 0.5 * kl_divergence(left_complete, midpoint, base) + 0.5 * kl_divergence(right_complete, midpoint, base)


def bayes_risk(
    prior: Mapping[str, float],
    loss: Mapping[str, Mapping[str, float]],
    observation_map: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Calculate minimum finite Bayes risk after a deterministic observation.

    ``loss[state][action]`` supplies the loss. If ``observation_map`` is absent,
    all states share one observation (no information). When it maps each state to
    itself, the result is full-state-information risk.
    """

    validate_distribution(prior)
    states = sorted(prior)
    if set(loss) != set(states):
        raise ValueError("Loss matrix must contain exactly the prior states")
    actions = sorted(set.intersection(*(set(loss[state]) for state in states)))
    if not actions:
        raise ValueError("No action is common to every state")
    mapping = observation_map or {state: "OBS" for state in states}
    if set(mapping) != set(states):
        raise ValueError("Observation map must contain exactly the prior states")

    observations: defaultdict[str, list[str]] = defaultdict(list)
    for state, observation in mapping.items():
        observations[str(observation)].append(state)

    total_risk = 0.0
    policy: dict[str, str] = {}
    observation_risks: dict[str, float] = {}
    for observation, member_states in sorted(observations.items()):
        expected_by_action = {
            action: sum(float(prior[state]) * float(loss[state][action]) for state in member_states)
            for action in actions
        }
        best_action, best_risk = min(expected_by_action.items(), key=lambda item: (item[1], item[0]))
        policy[observation] = best_action
        observation_risks[observation] = best_risk
        total_risk += best_risk
    return {"risk": total_risk, "policy": policy, "observation_risks": observation_risks}


def statistic_risk_audit(contract: Mapping[str, Any]) -> dict[str, Any]:
    prior = {str(key): float(value) for key, value in contract.get("prior", {}).items()}
    loss = {
        str(state): {str(action): float(value) for action, value in actions.items()}
        for state, actions in contract.get("loss", {}).items()
    }
    statistic = {str(key): str(value) for key, value in contract.get("statistic", {}).items()}
    if not prior or not loss or not statistic:
        return {"state": AuditState.NOT_APPLICABLE.value, "reason": "prior/loss/statistic not supplied"}
    full = bayes_risk(prior, loss, {state: state for state in prior})
    compressed = bayes_risk(prior, loss, statistic)
    increase = compressed["risk"] - full["risk"]
    return {
        "state": AuditState.PASS.value if increase <= TOLERANCE else AuditState.WARN.value,
        "full_information_risk": full,
        "statistic_risk": compressed,
        "risk_increase": increase,
        "decision_sufficient": increase <= TOLERANCE,
        "boundary": "Decision sufficiency is relative to the declared prior, action set, and loss matrix.",
    }


def audit_information_contract(contract: Mapping[str, Any]) -> dict[str, Any]:
    if not contract:
        return {"state": AuditState.NOT_APPLICABLE.value, "reason": "No information contract supplied"}
    errors: list[str] = []
    warnings: list[str] = []
    metrics: dict[str, Any] = {}
    try:
        source = {str(key): float(value) for key, value in contract.get("source_distribution", {}).items()}
        first = {
            str(state): {str(outcome): float(probability) for outcome, probability in row.items()}
            for state, row in contract.get("channel_y_given_x", {}).items()
        }
        if source and first:
            metrics["H_X_bits"] = entropy(source)
            metrics["output_Y"] = channel_output_distribution(source, first)
            metrics["I_XY_bits"] = mutual_information(source, first)
        second = {
            str(state): {str(outcome): float(probability) for outcome, probability in row.items()}
            for state, row in contract.get("channel_z_given_y", {}).items()
        }
        if source and first and second:
            composed = compose_channels(first, second)
            metrics["output_Z"] = channel_output_distribution(source, composed)
            metrics["I_XZ_bits"] = mutual_information(source, composed)
            metrics["data_processing_gap_bits"] = metrics["I_XY_bits"] - metrics["I_XZ_bits"]
            metrics["data_processing_holds"] = metrics["I_XZ_bits"] <= metrics["I_XY_bits"] + TOLERANCE
            if not metrics["data_processing_holds"]:
                errors.append("Data-processing inequality failed; inspect probability tables or implementation")
        metrics["statistic_risk"] = statistic_risk_audit(contract.get("decision_problem", {}))
    except (TypeError, ValueError, KeyError) as exc:
        errors.append(str(exc))

    if not source:
        warnings.append("No finite source distribution supplied")
    return {
        "state": AuditState.FAIL.value if errors else (AuditState.WARN.value if warnings else AuditState.PASS.value),
        "metrics": metrics,
        "errors": errors,
        "warnings": warnings,
        "boundary": (
            "Finite encoded Shannon/decision results certify only the declared table. They do not establish "
            "that semantic, physical, causal, or biological reality is exhausted by that table."
        ),
    }
