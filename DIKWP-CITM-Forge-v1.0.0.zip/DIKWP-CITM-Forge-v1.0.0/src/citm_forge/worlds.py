"""Plural world-model audit and bounded discriminating-probe selection."""

from __future__ import annotations

from itertools import combinations
from typing import Any, Iterable

from .canonical import sha256_object
from .information import jensen_shannon, validate_distribution
from .model import AuditState, CandidateProbe, ImpactLevel, WorldModel


def structure_signature(model: WorldModel) -> str:
    return sha256_object({"family": model.family, "structure": model.structure})


def audit_world_models(
    models: Iterable[WorldModel], probes: Iterable[CandidateProbe], impact_level: ImpactLevel
) -> dict[str, Any]:
    model_list = tuple(models)
    probe_list = tuple(probes)
    errors: list[str] = []
    warnings: list[str] = []
    signatures = {model.id: structure_signature(model) for model in model_list}
    distinct_signatures = set(signatures.values())

    if impact_level == ImpactLevel.HIGH and len(distinct_signatures) < 2:
        warnings.append("High-impact task lacks two non-isomorphic world models")

    probe_by_id = {probe.id: probe for probe in probe_list}
    pairwise: list[dict[str, Any]] = []
    scores: dict[str, float] = {probe.id: 0.0 for probe in probe_list}
    pair_count_by_probe: dict[str, int] = {probe.id: 0 for probe in probe_list}

    for model in model_list:
        for probe_id, distribution in model.predictions.items():
            try:
                validate_distribution(distribution)
            except ValueError as exc:
                errors.append(f"Model {model.id}, probe {probe_id}: {exc}")
            if probe_id not in probe_by_id:
                warnings.append(f"Model {model.id} predicts undeclared probe {probe_id}")

    for left, right in combinations(model_list, 2):
        common_probes = sorted(set(left.predictions) & set(right.predictions) & set(probe_by_id))
        for probe_id in common_probes:
            divergence = jensen_shannon(left.predictions[probe_id], right.predictions[probe_id])
            cost = max(probe_by_id[probe_id].cost, 1e-12)
            score = divergence / cost
            scores[probe_id] += score
            pair_count_by_probe[probe_id] += 1
            pairwise.append(
                {
                    "left_model": left.id,
                    "right_model": right.id,
                    "probe_id": probe_id,
                    "jensen_shannon_bits": divergence,
                    "cost": cost,
                    "discrimination_per_cost": score,
                }
            )

    eligible: list[dict[str, Any]] = []
    for probe in probe_list:
        average = scores[probe.id] / pair_count_by_probe[probe.id] if pair_count_by_probe[probe.id] else 0.0
        authorised = bool(probe.authorised_by)
        eligible.append(
            {
                "probe_id": probe.id,
                "average_discrimination_per_cost": average,
                "reversible": probe.reversible,
                "authorised": authorised,
                "authorised_by": probe.authorised_by,
                "eligible_for_recommendation": probe.reversible and authorised,
                "description": probe.description,
            }
        )
    eligible.sort(key=lambda item: (-item["average_discrimination_per_cost"], item["probe_id"]))
    recommended = next((item for item in eligible if item["eligible_for_recommendation"]), None)
    if probe_list and not recommended:
        warnings.append("No probe is both reversible and explicitly authorised; no intervention is recommended")

    state = AuditState.FAIL if errors else (AuditState.WARN if warnings else AuditState.PASS)
    return {
        "state": state.value,
        "model_count": len(model_list),
        "distinct_structure_count": len(distinct_signatures),
        "structure_signatures": signatures,
        "non_isomorphic_requirement": "at least two for high-impact tasks",
        "pairwise_probe_scores": pairwise,
        "probe_ranking": eligible,
        "recommended_probe": recommended,
        "automatic_external_action_authority": 0,
        "errors": errors,
        "warnings": sorted(set(warnings)),
        "boundary": (
            "A recommended probe is an analysis result only. Execution requires the named authority, a finite lease, "
            "and an independently enforced action boundary."
        ),
    }
