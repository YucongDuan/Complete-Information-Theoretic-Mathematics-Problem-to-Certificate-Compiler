"""Bundled deterministic reference data."""
