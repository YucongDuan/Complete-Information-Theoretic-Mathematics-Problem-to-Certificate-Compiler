"""Core immutable-ish data model for DIKWP-CITM Forge."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Iterable, Mapping

from .errors import ValidationError


class RecordKind(str, Enum):
    D = "D"
    I = "I"
    K = "K"
    W = "W"
    P = "P"


class ImpactLevel(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class AuditState(str, Enum):
    PASS = "PASS"
    WARN = "WARN"
    FAIL = "FAIL"
    OPEN = "OPEN"
    NOT_APPLICABLE = "NOT_APPLICABLE"
    NOT_ESTABLISHED = "NOT_ESTABLISHED"


class ClaimState(str, Enum):
    PROTOCOL_VALID = "PROTOCOL_VALID"
    VERIFIED_WITHIN_DECLARED_SCOPE = "VERIFIED_WITHIN_DECLARED_SCOPE"
    EQUIVALENCE_VERIFIED_WITHIN_DECLARED_SCOPE = "EQUIVALENCE_VERIFIED_WITHIN_DECLARED_SCOPE"
    REDUCTION_ONLY = "REDUCTION_ONLY"
    OPEN = "OPEN"
    NOT_ESTABLISHED = "NOT_ESTABLISHED"
    REFUSED_OVERCLAIM = "REFUSED_OVERCLAIM"
    FAILED = "FAILED"


class ObligationState(str, Enum):
    VERIFIED = "VERIFIED"
    OPEN = "OPEN"
    FAILED = "FAILED"
    EXTERNAL = "EXTERNAL"
    NOT_APPLICABLE = "NOT_APPLICABLE"


@dataclass(frozen=True)
class SemanticRecord:
    id: str
    kind: RecordKind
    content: str
    provenance: tuple[str, ...] = ()
    predecessors: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "SemanticRecord":
        try:
            kind = RecordKind(str(raw["kind"]))
            identifier = str(raw["id"]).strip()
            content = str(raw["content"]).strip()
        except (KeyError, ValueError, TypeError) as exc:
            raise ValidationError(f"Invalid semantic record: {raw!r}") from exc
        if not identifier or not content:
            raise ValidationError("Record id and content must be non-empty")
        return cls(
            id=identifier,
            kind=kind,
            content=content,
            provenance=tuple(str(item) for item in raw.get("provenance", [])),
            predecessors=tuple(str(item) for item in raw.get("predecessors", [])),
            metadata=dict(raw.get("metadata", {})),
        )


@dataclass(frozen=True)
class Route:
    id: str
    source: str
    target: str
    generated_content: str
    evidence: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "Route":
        required = ("id", "source", "target", "generated_content")
        if any(key not in raw for key in required):
            raise ValidationError(f"Route missing a required field: {raw!r}")
        values = [str(raw[key]).strip() for key in required]
        if any(not value for value in values):
            raise ValidationError("Route id, source, target, and generated content must be non-empty")
        return cls(
            id=values[0],
            source=values[1],
            target=values[2],
            generated_content=values[3],
            evidence=tuple(str(item) for item in raw.get("evidence", [])),
            metadata=dict(raw.get("metadata", {})),
        )


@dataclass(frozen=True)
class ConceptAlias:
    id: str
    label: str
    record_ids: tuple[str, ...]
    predecessors: tuple[str, ...] = ()
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "ConceptAlias":
        identifier = str(raw.get("id", "")).strip()
        label = str(raw.get("label", "")).strip()
        records = tuple(str(item) for item in raw.get("record_ids", []))
        if not identifier or not label or not records:
            raise ValidationError("Alias requires id, label, and at least one record id")
        return cls(
            id=identifier,
            label=label,
            record_ids=records,
            predecessors=tuple(str(item) for item in raw.get("predecessors", [])),
            metadata=dict(raw.get("metadata", {})),
        )


@dataclass(frozen=True)
class ProblemContract:
    id: str
    title: str
    objects: tuple[str, ...]
    scope: str
    quantifiers: tuple[str, ...]
    operations: tuple[str, ...]
    environment: str
    terminal_condition: str
    concept_return: str
    version_migration: str
    prohibited_inferences: tuple[str, ...] = ()
    reopening_conditions: tuple[str, ...] = ()
    inherited_standard: str = ""

    DIMENSIONS = (
        "objects",
        "scope",
        "quantifiers",
        "operations",
        "environment",
        "terminal_condition",
        "concept_return",
        "version_migration",
    )

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "ProblemContract":
        scalar_required = (
            "id",
            "title",
            "scope",
            "environment",
            "terminal_condition",
            "concept_return",
            "version_migration",
        )
        if any(not str(raw.get(key, "")).strip() for key in scalar_required):
            missing = [key for key in scalar_required if not str(raw.get(key, "")).strip()]
            raise ValidationError(f"Problem contract missing: {', '.join(missing)}")
        objects = tuple(str(item).strip() for item in raw.get("objects", []) if str(item).strip())
        quantifiers = tuple(str(item).strip() for item in raw.get("quantifiers", []) if str(item).strip())
        operations = tuple(str(item).strip() for item in raw.get("operations", []) if str(item).strip())
        if not objects or not quantifiers or not operations:
            raise ValidationError("Problem contract requires objects, quantifiers, and operations")
        return cls(
            id=str(raw["id"]),
            title=str(raw["title"]),
            objects=objects,
            scope=str(raw["scope"]),
            quantifiers=quantifiers,
            operations=operations,
            environment=str(raw["environment"]),
            terminal_condition=str(raw["terminal_condition"]),
            concept_return=str(raw["concept_return"]),
            version_migration=str(raw["version_migration"]),
            prohibited_inferences=tuple(str(item) for item in raw.get("prohibited_inferences", [])),
            reopening_conditions=tuple(str(item) for item in raw.get("reopening_conditions", [])),
            inherited_standard=str(raw.get("inherited_standard", "")),
        )


@dataclass(frozen=True)
class WorldModel:
    id: str
    family: str
    structure: Mapping[str, Any]
    predictions: Mapping[str, Mapping[str, float]]
    assumptions: tuple[str, ...] = ()
    retirement_conditions: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "WorldModel":
        identifier = str(raw.get("id", "")).strip()
        family = str(raw.get("family", "")).strip()
        predictions = raw.get("predictions", {})
        if not identifier or not family or not isinstance(predictions, Mapping):
            raise ValidationError(f"Invalid world model: {raw!r}")
        return cls(
            id=identifier,
            family=family,
            structure=dict(raw.get("structure", {})),
            predictions={
                str(probe): {str(outcome): float(prob) for outcome, prob in distribution.items()}
                for probe, distribution in predictions.items()
            },
            assumptions=tuple(str(item) for item in raw.get("assumptions", [])),
            retirement_conditions=tuple(str(item) for item in raw.get("retirement_conditions", [])),
        )


@dataclass(frozen=True)
class CandidateProbe:
    id: str
    cost: float
    reversible: bool
    authorised_by: str
    description: str = ""

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "CandidateProbe":
        identifier = str(raw.get("id", "")).strip()
        if not identifier:
            raise ValidationError("Probe id is required")
        return cls(
            id=identifier,
            cost=float(raw.get("cost", 1.0)),
            reversible=bool(raw.get("reversible", False)),
            authorised_by=str(raw.get("authorised_by", "")).strip(),
            description=str(raw.get("description", "")),
        )


@dataclass(frozen=True)
class ProofObligation:
    id: str
    claim: str
    verifier: Mapping[str, Any]
    scope: str
    dependencies: tuple[str, ...] = ()
    retirement_conditions: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "ProofObligation":
        identifier = str(raw.get("id", "")).strip()
        claim = str(raw.get("claim", "")).strip()
        scope = str(raw.get("scope", "")).strip()
        verifier = raw.get("verifier", {})
        if not identifier or not claim or not scope or not isinstance(verifier, Mapping):
            raise ValidationError(f"Invalid proof obligation: {raw!r}")
        return cls(
            id=identifier,
            claim=claim,
            verifier=dict(verifier),
            scope=scope,
            dependencies=tuple(str(item) for item in raw.get("dependencies", [])),
            retirement_conditions=tuple(str(item) for item in raw.get("retirement_conditions", [])),
        )


@dataclass(frozen=True)
class ReductionContract:
    id: str
    source_claim: str
    target_claim: str
    forward_map: str
    backward_map: str
    soundness_obligation_id: str
    completeness_obligation_id: str
    target_verification_obligation_id: str
    scope: str

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "ReductionContract":
        fields = (
            "id",
            "source_claim",
            "target_claim",
            "forward_map",
            "backward_map",
            "soundness_obligation_id",
            "completeness_obligation_id",
            "target_verification_obligation_id",
            "scope",
        )
        values = {key: str(raw.get(key, "")).strip() for key in fields}
        missing = [key for key, value in values.items() if not value]
        if missing:
            raise ValidationError(f"Reduction missing: {', '.join(missing)}")
        return cls(**values)


@dataclass(frozen=True)
class Project:
    metadata: Mapping[str, Any]
    problem_contract: ProblemContract
    records: tuple[SemanticRecord, ...]
    routes: tuple[Route, ...]
    aliases: tuple[ConceptAlias, ...]
    world_models: tuple[WorldModel, ...]
    probes: tuple[CandidateProbe, ...]
    proof_obligations: tuple[ProofObligation, ...]
    reductions: tuple[ReductionContract, ...]
    information_contract: Mapping[str, Any]
    future_effect_system: Mapping[str, Any]
    claims: tuple[Mapping[str, Any], ...]

    @classmethod
    def from_dict(cls, raw: Mapping[str, Any]) -> "Project":
        metadata = dict(raw.get("metadata", {}))
        if not str(metadata.get("project_id", "")).strip():
            raise ValidationError("metadata.project_id is required")
        try:
            ImpactLevel(str(metadata.get("impact_level", "medium")))
        except ValueError as exc:
            raise ValidationError("metadata.impact_level must be low, medium, or high") from exc
        return cls(
            metadata=metadata,
            problem_contract=ProblemContract.from_dict(raw.get("problem_contract", {})),
            records=tuple(SemanticRecord.from_dict(item) for item in raw.get("records", [])),
            routes=tuple(Route.from_dict(item) for item in raw.get("routes", [])),
            aliases=tuple(ConceptAlias.from_dict(item) for item in raw.get("aliases", [])),
            world_models=tuple(WorldModel.from_dict(item) for item in raw.get("world_models", [])),
            probes=tuple(CandidateProbe.from_dict(item) for item in raw.get("candidate_probes", [])),
            proof_obligations=tuple(
                ProofObligation.from_dict(item) for item in raw.get("proof_obligations", [])
            ),
            reductions=tuple(ReductionContract.from_dict(item) for item in raw.get("reductions", [])),
            information_contract=dict(raw.get("information_contract", {})),
            future_effect_system=dict(raw.get("future_effect_system", {})),
            claims=tuple(dict(item) for item in raw.get("claims", [])),
        )

    @property
    def project_id(self) -> str:
        return str(self.metadata["project_id"])

    @property
    def impact_level(self) -> ImpactLevel:
        return ImpactLevel(str(self.metadata.get("impact_level", "medium")))

    def records_by_id(self) -> dict[str, SemanticRecord]:
        return {record.id: record for record in self.records}


def ensure_unique(values: Iterable[str], label: str) -> None:
    seen: set[str] = set()
    duplicates: set[str] = set()
    for value in values:
        if value in seen:
            duplicates.add(value)
        seen.add(value)
    if duplicates:
        raise ValidationError(f"Duplicate {label}: {', '.join(sorted(duplicates))}")
