"""Bilingual Markdown report generation."""

from __future__ import annotations

from typing import Any, Mapping


def _state(value: Any) -> str:
    return str(value if value is not None else "OPEN")


def render_report(certificate: Mapping[str, Any], audit: Mapping[str, Any]) -> str:
    project_id = certificate["project_id"]
    title = certificate["problem_title"]
    closure = audit["native_core"]["route_audit"]["closure_vector"]
    responsibility = certificate["nonaggregated_settlement"]
    claims = certificate.get("claim_results", [])
    obligations = audit.get("proof_obligations", {}).get("results", {})
    reductions = audit.get("reductions", {}).get("results", [])

    lines: list[str] = [
        f"# DIKWP-CITM Forge Audit / 审计报告 — `{project_id}`",
        "",
        f"**Problem / 问题：** {title}",
        "",
        f"**Run hash / 运行哈希：** `{certificate['run_hash']}`",
        "",
        f"**Ledger head / 账本头：** `{certificate['ledger_head_hash']}`",
        "",
        f"**D/I/K/W/P closure vector / 闭合向量：** `{closure}`",
        "",
        f"**Global closure claim / 全局闭合主张：** `{certificate['global_closure_claim']}`",
        "",
        f"**External-domain settlement / 外部领域结算：** `{certificate['external_domain_settlement']}`",
        "",
        "## 1. Non-aggregated settlement / 非聚合结算",
        "",
        "| Relation / 关系 | State / 状态 | Basis / 依据 |",
        "|---|---|---|",
    ]
    for key, item in responsibility.items():
        lines.append(f"| `{key}` | `{_state(item.get('state'))}` | {item.get('basis', '')} |")

    lines.extend(
        [
            "",
            "## 2. Nine-stage pipeline / 九阶段运行链",
            "",
            "| # | Stage | State |",
            "|---:|---|---|",
        ]
    )
    for index, stage in enumerate(audit.get("pipeline", []), start=1):
        lines.append(f"| {index} | `{stage['id']}` — {stage['name']} | `{stage['state']}` |")

    lines.extend(["", "## 3. Claims / 主张", ""])
    if claims:
        lines.extend(["| ID | Requested | Issued | Boundary |", "|---|---|---|---|"])
        for claim in claims:
            lines.append(
                f"| `{claim['id']}` | `{claim['requested_state']}` | `{claim['issued_state']}` | {claim['boundary']} |"
            )
    else:
        lines.append("No explicit claims were supplied. / 未提供显式主张。")

    lines.extend(["", "## 4. Proof obligations / 证明义务", ""])
    if obligations:
        lines.extend(["| ID | State | Scope | Claim |", "|---|---|---|---|"])
        for obligation_id, item in sorted(obligations.items()):
            lines.append(
                f"| `{obligation_id}` | `{item['state']}` | {item.get('scope', '')} | {item.get('claim', '')} |"
            )
    else:
        lines.append("No proof obligations supplied. / 未提供证明义务。")

    lines.extend(["", "## 5. Reduction firewall / 还原防火墙", ""])
    if reductions:
        lines.extend(["| Reduction | State | Equivalence | Target verified |", "|---|---|---:|---:|"])
        for item in reductions:
            lines.append(
                f"| `{item['reduction_id']}` | `{item['claim_state']}` | {item['equivalence_verified']} | {item['target_verified']} |"
            )
    else:
        lines.append("No reduction contracts supplied. / 未提供还原合同。")

    world = audit.get("world_models", {})
    lines.extend(
        [
            "",
            "## 6. World-model plurality and probes / 多世界模型与探针",
            "",
            f"- Models / 模型数：**{world.get('model_count', 0)}**",
            f"- Distinct structures / 非同构结构数：**{world.get('distinct_structure_count', 0)}**",
            f"- Automatic external-action authority / 自动外部行动权：**{world.get('automatic_external_action_authority', 0)}**",
            f"- Recommended probe / 推荐探针：`{(world.get('recommended_probe') or {}).get('probe_id', 'NONE')}`",
            "",
            "A recommendation is not an execution authorisation. / 推荐不构成执行授权。",
        ]
    )

    lines.extend(
        [
            "",
            "## 7. Integrity / 完整性",
            "",
            f"- Project hash: `{certificate['project_hash']}`",
            f"- Audit hash: `{certificate['audit_hash']}`",
            f"- Certificate body hash: `{certificate['certificate_body_hash']}`",
            f"- Ledger event count: **{certificate['ledger_event_count']}**",
            "",
            "## 8. Boundary / 边界",
            "",
            certificate["boundary_statement_en"],
            "",
            certificate["boundary_statement_cn"],
            "",
        ]
    )
    return "\n".join(lines)
