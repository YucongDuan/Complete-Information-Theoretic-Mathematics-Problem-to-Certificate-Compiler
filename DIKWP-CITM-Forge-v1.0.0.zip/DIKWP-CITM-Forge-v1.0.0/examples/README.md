# Examples

| Directory | Purpose | Expected boundary |
|---|---|---|
| `01_future_effect_quotient` | Recompute a finite future-effect quotient and refine it with a new continuation | Exact only for the declared finite continuation family |
| `02_information_channel` | Shannon information, channel composition, data-processing and decision sufficiency | Exact only for the supplied probability/loss tables |
| `03_typed_zero` | Preserve EMPTY_SCOPE, CANCELLATION, ORIGIN and UNOBSERVED under a shared symbol | No claim that every zero use is captured |
| `04_multiworld_probe` | Keep two non-isomorphic models and rank reversible authorised probes | Ranking is not execution |
| `05_goldbach_finite` | Generate/check finite prime-pair witnesses and refuse global overclaim | Does not solve unrestricted Goldbach |
| `open_problems` | Seven explicit inherited-problem registers | `OPEN` / `NOT_ESTABLISHED` where proof is absent |

Compile any example with:

```bash
PYTHONPATH=src python -m citm_forge compile examples/01_future_effect_quotient/project.json \
  --output outputs/quotient
```
