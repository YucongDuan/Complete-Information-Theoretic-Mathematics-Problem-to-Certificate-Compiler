#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$ROOT"
PYTHONPATH="$ROOT/src${PYTHONPATH:+:$PYTHONPATH}" python -m citm_forge demo --output "$ROOT/outputs/demo"
printf '\nOpen the offline dashboard:\n  %s\n' "$ROOT/web/DIKWP_CITM_Forge_Offline_Demo.html"
