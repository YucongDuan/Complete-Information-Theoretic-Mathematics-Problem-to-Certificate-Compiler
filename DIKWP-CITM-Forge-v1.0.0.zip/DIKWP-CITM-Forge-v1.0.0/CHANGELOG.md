# Changelog

## 1.0.0 — 2026-08-23

- Initial open-source reference release.
- Nine-stage deterministic problem-to-certificate compiler.
- D/I/K/W/P multi-record model and all twenty-five route kinds.
- W→P, P→output, reverse-P, and D-sameness audits.
- Finite entropy, mutual information, channel composition, data-processing, and Bayes-risk tools.
- Future-effect quotient with append-only refinement.
- Plural world models and reversible named-authority probe ranking.
- Safe finite verifiers and unrestricted-claim refusal.
- Reduction soundness/completeness/target firewall.
- Hash chain, manifests, Merkle root, SBOM, release verification, and offline dashboard.
- Bilingual documentation and seven explicit open-problem registers.
