# Authors and Source Lineage

## Principal author and maintainer

**Yucong Duan (Henry Duan)**  
Hainan University  
Public code profile: https://github.com/YucongDuan

## Theoretical source co-author

**Feng Wang**

## Source works

- 段玉聪、王锋，《宇宙的数学新史：从原生语义连续、概念再生到自编译宇宙》，2026。
- Yucong Duan and Feng Wang, *A New Mathematical History of the Universe: Native Semantic Continuity, Concept Regeneration, and the Self-Revising Cosmos*, 2026.

This package preserves the source books' joint authorship. Software forks and derivative interfaces must retain the applicable copyright, NOTICE, citation, and revision-lineage records.
