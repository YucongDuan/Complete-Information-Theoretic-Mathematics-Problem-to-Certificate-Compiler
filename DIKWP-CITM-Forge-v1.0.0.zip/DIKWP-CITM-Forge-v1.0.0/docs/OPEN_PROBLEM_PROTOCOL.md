# Open-Problem Protocol / 未解问题协议

## 1. Preserve the inherited problem

An open problem entry must record the original object domain, quantifiers, operations, ambient theory, and settlement standard. A new information representation is admissible only as a carrier or candidate bridge until reverse reconstruction returns to the inherited statement.

## 2. Separate four outputs

1. **Representation:** a new encoding, channel, quotient, invariant, or semantic address.
2. **Reduction:** maps between the inherited problem and a target condition.
3. **Local result:** finite range, restricted class, conditional theorem, computation, or experiment.
4. **Unrestricted settlement:** a proof/counterexample satisfying the inherited standard.

The first three may be valuable without being the fourth.

## 3. Required obligations

Every proposed resolution should register:

- object-fidelity obligation;
- quantifier-fidelity obligation;
- forward-map soundness;
- backward-map completeness;
- target theorem obligation;
- verifier/replay obligation;
- assumption and dependency ledger;
- reopening and model-retirement conditions;
- independent reconstruction route.

## 4. Included registers

The repository includes non-solution templates for Goldbach, P versus NP, Riemann, BSD, Hodge, Navier–Stokes, and Yang–Mills. They are intentionally marked `NOT_ESTABLISHED` or `OPEN` where the required proof is absent.

## 5. Finite Goldbach example

The reference runtime generates and verifies prime-pair witnesses on a bounded interval. It thereby proves the finite quantified statement encoded in that interval. The certificate states the exact range and refuses the unrestricted conjecture.

## 6. Publication handoff

A candidate unrestricted proof should be exported to an appropriate formal or conventional mathematical carrier, independently reconstructed, openly reviewed, and versioned. DIKWP-CITM Forge can preserve the handoff, but it cannot substitute its own name for that process.
