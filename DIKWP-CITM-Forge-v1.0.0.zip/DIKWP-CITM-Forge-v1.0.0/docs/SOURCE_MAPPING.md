# Theoretical Source Mapping

| Source discipline | Runtime realisation |
|---|---|
| Five native positions with multiple records | `model.SemanticRecord`, `RecordKind` |
| Twenty-five record-level routes | `routes.ALL_ROUTE_KINDS`, `RouteAudit` |
| Append-only lineage | stable ids, predecessors, `HashChainLedger` |
| External concept aliases | `ConceptAlias`, zero native authority audit |
| Operational W and executable P | W→P reachability and P→output audit |
| Bidirectional regeneration | forward P, candidate K, reverse P, regenerated output, D-sameness |
| Future-effect quotient | `quotient.future_effect_quotient` |
| Local worlds and discriminating contact | `worlds.audit_world_models` |
| Nine-stage software ledger | `compiler.PIPELINE` |
| Machine proof responsibility packages | problem contract, obligations, certificate, report |
| Explicit not-given/open positions | `OPEN`, `NOT_ESTABLISHED`, `NOT_ISSUED` |
| Deterministic replay | canonical JSON, hash chain, run hash, manifests |
| Reduction does not equal proof | `reduction.audit_reduction` |

The software is an implementation of a declared protocol. It is not evidence that the source books' physical, biological, consciousness, or unrestricted mathematical projections have thereby been externally settled.
