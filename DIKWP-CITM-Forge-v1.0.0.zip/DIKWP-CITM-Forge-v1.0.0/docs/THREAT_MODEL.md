# Threat Model

## Protected assets

- object and quantifier fidelity;
- provenance and predecessor lineage;
- explicit open positions;
- finite/unrestricted scope separation;
- route and certificate integrity;
- author and source attribution;
- named authority and action boundaries.

## Principal threats

1. **Object drift:** a verifier proves a nearby but different statement.
2. **Quantifier laundering:** finite success is reported as an unrestricted theorem.
3. **Reduction laundering:** an equivalence metaphor is reported as a completed proof.
4. **Carrier annexation:** a fluent alias supplies records not present in the core.
5. **Collision erasure:** conflicting routes are silently merged.
6. **Ledger mutation:** earlier evidence is changed after the result.
7. **Model monoculture:** one high-impact model is treated as final authority.
8. **Action escalation:** an analytical probe ranking triggers external execution.
9. **Arbitrary-code injection:** a project file attempts to execute local or remote code.
10. **Credit erasure:** derived systems drop the theoretical source and revision lineage.

## Controls

- declarative JSON only;
- closed verifier whitelist;
- no network/tool/credential/physical-action interface;
- SHA-256 chain and manifest;
- stable identifiers and append-only successors;
- visible route collisions;
- high-impact non-isomorphic model warning;
- automatic action authority fixed at zero;
- explicit `NOT_ISSUED` and `NOT_ESTABLISHED` boundaries;
- source mapping, NOTICE, CITATION, and version records.

## Non-goals

The package is not a hardened multi-tenant service, formal proof assistant kernel, empirical laboratory, or external publication/acceptance oracle.
