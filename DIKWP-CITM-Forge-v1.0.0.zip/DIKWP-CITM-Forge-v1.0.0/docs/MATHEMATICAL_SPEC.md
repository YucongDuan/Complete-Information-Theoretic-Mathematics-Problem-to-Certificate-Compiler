# Mathematical Specification / 数学规范

## 1. Complete finite information object

A finite encoded experiment may be represented by

\[
\mathfrak I=(X,Y,K,\mathcal A,\ell,T,V,\Gamma),
\]

where `X` is a finite state family, `Y` an observation family, `K(y|x)` a channel, `A` a finite action family, `ℓ(x,a)` a declared loss, `T` a statistic/compression, `V` a finite verifier, and `Γ` the declared transformation/intervention family.

The runtime does not infer that this encoding exhausts an external domain.

## 2. Future-effect quotient

For histories `h,k` and admitted continuations `C`,

\[
h \equiv_C k \iff \forall c\in C,\; \operatorname{Effect}(h,c)=\operatorname{Effect}(k,c).
\]

The quotient `H/≡C` is the coarsest partition that preserves every encoded future effect. Adding continuations can only preserve or refine the partition; it cannot validly merge histories separated by an earlier continuation.

## 3. Shannon information

For a finite distribution `p`,

\[
H(X)=-\sum_x p(x)\log_2 p(x).
\]

For a channel `K(y|x)`, the runtime computes `I(X;Y)` and, for a Markov chain `X→Y→Z`, checks

\[
I(X;Z)\le I(X;Y).
\]

The result is a theorem about the supplied finite probability tables, not a universal semantic identity.

## 4. Decision sufficiency

For statistic `T`, prior `p`, actions `A`, and loss `ℓ`, the runtime compares minimum Bayes risk with full-state observation and with observation of `T`. `T` is decision-sufficient only relative to that declared decision problem when no risk increase occurs.

## 5. World-model discrimination

For two finite predictive distributions `P` and `Q`, the system uses Jensen–Shannon divergence. A probe score is

\[
\operatorname{score}(q)=\frac{\operatorname{JSD}(P_q,Q_q)}{\operatorname{cost}(q)}.
\]

A probe enters the recommendation set only when it is explicitly reversible and names its authorising principal. The score carries no execution authority.

## 6. Reduction firewall

For source claim `A` and information-theoretic target claim `B`, a reduction package must separately register:

1. forward map;
2. backward map;
3. soundness obligation;
4. completeness obligation;
5. target verification obligation;
6. common scope.

`A↔B` or a textual correspondence does not establish `A`. The source claim can be transported back only after soundness, completeness, and target verification are all verified in the same scope.

## 7. Certificate lattice

Certificates are deliberately not totally ordered. `PROTOCOL_VALID`, `VERIFIED_WITHIN_DECLARED_SCOPE`, `REDUCTION_ONLY`, `OPEN`, and `NOT_ESTABLISHED` record different relations. A strong finite certificate does not dominate an open external theorem obligation.
