# User Guide

1. Copy an example `project.json`.
2. Freeze the eight-dimensional problem contract.
3. Add provenance-bearing D/I/K/W/P records.
4. Add explicit routes with source, target, and generated content.
5. Declare proof obligations and claim scopes.
6. Compile with `python -m citm_forge compile ...`.
7. Inspect the non-aggregated report, not a single headline state.
8. Verify the ledger and manifest.
9. Append successor records for any scope, evidence, model, or verifier change; never overwrite an old certificate.

See the Chinese guide for a field-by-field description and `schemas/project.schema.json` for the machine-readable interface.
