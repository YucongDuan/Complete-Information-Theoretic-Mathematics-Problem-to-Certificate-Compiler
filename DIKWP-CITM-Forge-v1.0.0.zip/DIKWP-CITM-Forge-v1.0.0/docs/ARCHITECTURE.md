# Architecture / 系统架构

## 1. Design objective

DIKWP-CITM Forge is a compiler, not a theorem oracle. Its input is a declarative project. Its output is a scope-bounded certificate and a replayable evidence lineage.

```text
Project JSON
  ├─ problem contract (8 dimensions)
  ├─ D/I/K/W/P records
  ├─ explicit record-level routes
  ├─ concept aliases (zero native authority)
  ├─ finite information contract
  ├─ future-effect system
  ├─ plural world models and probes
  ├─ proof obligations
  ├─ reductions
  └─ requested claims
          │
          ▼
Nine-stage compiler + append-only ledger
          │
          ▼
Audit + certificate + report + manifest
```

## 2. Nine stages

| Stage | Function | Refusal boundary |
|---|---|---|
| S1 | Normalise the object contract | Missing dimensions are not guessed |
| S2 | Replay requested claims | Global/final solution requests are refused |
| S3 | Audit records, aliases, provenance | Alias fluency has zero native authority |
| S4 | Validate explicit routes and preserve collisions | Permitted route kind is not an actual route |
| S5 | Decompress W→P, P→output, reverse P and D-sameness | Open round trips remain OPEN |
| S6 | Audit quantifiers, finite information and verifiers | Finite checks do not become universal |
| S7 | Audit eight-dimensional bridge and plural models | Probe ranking does not authorise action |
| S8 | Extract maximum persistent core | Failed/open branches do not erase independent results |
| S9 | Issue non-aggregated certificate | No single total score launders an open relation |

## 3. Core invariants

1. Only D/I/K/W/P records form the native semantic core.
2. Every record has a stable identifier; successors append.
3. Every actual route names source, target, and generated content.
4. I-records and collisions remain visible after local closure.
5. W must reach the selected forward P.
6. P must name outputs and have explicit paths to them.
7. A strong round trip requires forward P, candidate K, reverse P, regenerated output, and D-sameness.
8. The problem contract preserves objects, scope, quantifiers, operations, environment, terminal condition, concept return, and version migration.
9. At least two non-isomorphic models are retained for high-impact projects.
10. Automatic external-action authority is zero.

## 4. Data flow

The compiler never executes code embedded in a project. Every verifier is selected from a closed declarative whitelist. External proof assistants, journals, laboratories, and institutions can later add attestations, but local software does not impersonate them.

## 5. Determinism

Canonical JSON, stable list ordering, no wall-clock ledger timestamp, SHA-256 chaining, and fixed verifier behaviour make reference runs reproducible. A run hash commits to the project hash, audit hash, certificate body hash, compiler identity, and final ledger head.
