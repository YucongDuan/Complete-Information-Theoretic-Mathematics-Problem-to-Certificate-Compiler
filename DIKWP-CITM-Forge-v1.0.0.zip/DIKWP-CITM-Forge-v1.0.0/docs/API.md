# Python API

```python
import json
from pathlib import Path
from citm_forge import ForgeCompiler

raw = json.loads(Path("project.json").read_text(encoding="utf-8"))
result = ForgeCompiler().compile(raw, Path("outputs/project"))
print(result.certificate["run_hash"])
```

## Stable public objects

- `ForgeCompiler`
- `CompileResult`
- `Project`
- `RecordKind`
- `AuditState`
- `ClaimState`
- `ObligationState`
- `ImpactLevel`

The JSON schemas are licensed under Apache-2.0 to support independent implementations.
