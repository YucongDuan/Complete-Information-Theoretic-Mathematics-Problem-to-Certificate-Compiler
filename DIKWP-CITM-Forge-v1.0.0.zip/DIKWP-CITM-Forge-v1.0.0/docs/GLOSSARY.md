# Glossary / 术语

- **Native record / 原生记录:** explicit D/I/K/W/P content with stable identity.
- **Concept alias / 概念别名:** human-readable address with zero authority to create missing records.
- **Route / 路径:** explicit source-record to target-record generation relation.
- **Future-effect quotient / 未来同效商:** coarsest partition preserving all declared continuation effects.
- **Open position / 开放位置:** required content/relation not yet supplied; not false and not zero reality.
- **D-sameness / D 同义登记:** explicit declaration of the aspect recovered between original and regenerated content.
- **Reduction firewall / 还原防火墙:** separation of transformation fidelity from target proof and source settlement.
- **Persistent core / 最大持续核心:** independently supported results retained when another branch remains open or fails.
- **Causal handoff / 因果交接:** named responsibility for the next bounded, reviewable action; the runtime itself executes none.
