# 用户手册（中文）

## 1. 项目文件

从 `examples/` 复制一个 `project.json`，修改：

- `metadata.project_id`：唯一项目号；
- `problem_contract`：八维对象合同；
- `records`：D/I/K/W/P 记录；
- `routes`：显式源—目标路径；
- `aliases`：仅用于可读索引；
- `proof_obligations`：验证器和范围；
- `claims`：希望系统审计的主张。

## 2. 编译

```bash
export PYTHONPATH="$PWD/src"
python -m citm_forge compile my_project.json --output outputs/my_project
```

## 3. 读取证书

先查看：

```bash
python -m citm_forge show-status outputs/my_project/certificate.json
```

再查看 `audit_report.md` 和 `audit.json`。不要只看一个总状态；系统采用非聚合结算。

## 4. 验证账本

```bash
python -m citm_forge verify-ledger outputs/my_project/ledger.jsonl
```

任何事件、顺序、前哈希或载荷被修改都会失败。

## 5. 证明义务

本地安全验证器支持：

- `goldbach_finite`；
- `finite_relations`；
- `truth_table`；
- `hash_match`；
- `external`（保持外部，不伪造结果）。

项目 JSON 中不能嵌入并执行 Python 或 Shell。

## 6. 多世界模型

高影响项目至少提供两个 `family/structure` 不同的模型。每个模型给出候选探针下的预测分布。探针只有同时满足“可逆”和“具名授权”才进入排序；系统仍不会执行它。

## 7. 版本迁移

不得复用旧记录 ID 覆盖内容。新增记录通过 `predecessors` 指向前序。新范围或新证明必须生成新的项目版本和证书。
