# Publication and Archival Plan

This local release is prepared for, but does not claim completion of, the following external actions:

1. create an authenticated repository under the author's account;
2. inspect every file and release boundary;
3. create a signed commit and version tag;
4. run CI and compare the reference run hash;
5. publish the source archive and standalone demo;
6. archive the release in a DOI-granting repository;
7. add the DOI to `CITATION.cff` only after issuance;
8. create a scholarly record linking the exact version;
9. preserve release hashes, signatures, and successor lineage.

No DOI, signature, institutional endorsement, GitHub release, or external publication is fabricated in this package.
