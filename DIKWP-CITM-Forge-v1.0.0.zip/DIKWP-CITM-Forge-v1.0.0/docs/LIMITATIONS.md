# Limitations

- Probability spaces, channels, losses, and future effects are finite and explicitly enumerated.
- Floating-point calculations are suitable for the supplied examples, not high-precision numerical certification.
- The primality checker is deterministic for ordinary finite integers but is not a formal proof-assistant kernel.
- No SMT/SAT/CAS/proof-assistant integration is included in the trusted core.
- World-model scores depend on declared predictions and costs.
- Non-isomorphism is approximated by distinct declared structural signatures, not solved as a general graph/model isomorphism problem.
- Cross-agent regeneration is represented by explicit records; the runtime does not infer private understanding.
- External mathematical acceptance, physical identity, life, and phenomenal consciousness remain outside local software authority.
