# DIKWP-CITM Forge 中文说明

DIKWP-CITM Forge 是一个面向完全信息理论数学的**问题—证书编译器**。它把一个问题的对象、范围、量词、运算、环境、终态、概念回写和版本迁移冻结为可重放合同，再把 D/I/K/W/P 多记录、二十五类显式路径、证明义务、信息信道、未来同效商和多世界模型编译为哈希链接证书。

## 系统不会做什么

系统不会把以下结果冒充为无界全称证明：

- 大量有限实例通过；
- 一个新的术语体系能够重述问题；
- 问题被还原为另一个信息论条件；
- 软件单元测试全部通过；
- 合成数据中的模型表现良好；
- 本地验证器接受了有限见证。

所以每次运行都固定输出：

```text
global_closure_claim = NOT_ISSUED
external_domain_settlement = NOT_ESTABLISHED
automatic_external_action_authority = 0
```

## 快速运行

```bash
cd DIKWP-CITM-Forge-v1.0.0
export PYTHONPATH="$PWD/src"
python -m citm_forge demo --output outputs/demo
```

Windows 双击 `run_demo.bat` 也可生成参考运行。

## 关键模块

- `model.py`：D/I/K/W/P 多记录、问题合同、世界模型和证明义务；
- `routes.py`：二十五类记录级路径、W→P、P→输出与双向再生；
- `information.py`：有限熵、互信息、信道复合、数据处理和决策风险；
- `quotient.py`：未来同效商和新增续生下的单调细化；
- `worlds.py`：高影响任务的非同构模型保留和可逆授权探针排序；
- `verifier.py`：不执行任意代码的有限声明式验证器；
- `reduction.py`：还原的可靠性、完备性和目标证明三重防火墙；
- `ledger.py`：追加式哈希事件谱系；
- `compiler.py`：九阶段编译与非聚合结算。

## 适合的用途

- 机器生成证明的对象忠实和量词审计；
- 未解问题的候选引理、还原和开放义务登记；
- 有限计算证书与全称定理之间的范围隔离；
- 数学模型、信息信道和决策损失的可重放比较；
- 跨载体概念回写、版本分化和来源谱系；
- 开源研究发布前的证据包、SBOM、哈希和边界核验。

完整设计见 `docs/`。
