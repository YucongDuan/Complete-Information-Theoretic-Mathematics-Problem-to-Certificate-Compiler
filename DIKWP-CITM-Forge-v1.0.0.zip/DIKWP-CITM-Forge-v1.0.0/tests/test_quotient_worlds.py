from __future__ import annotations

import unittest

from citm_forge.model import CandidateProbe, ImpactLevel, WorldModel
from citm_forge.quotient import future_effect_quotient
from citm_forge.worlds import audit_world_models


class QuotientWorldTests(unittest.TestCase):
    def test_future_quotient(self) -> None:
        result = future_effect_quotient(
            {
                "histories": ["a", "b", "c"],
                "continuations": ["x"],
                "effects": {"a|x": 1, "b|x": 1, "c|x": 2},
            }
        )
        self.assertEqual(result["quotient_classes"], [["a", "b"], ["c"]])

    def test_refinement_monotone(self) -> None:
        result = future_effect_quotient(
            {
                "histories": ["a", "b"],
                "continuations": ["x"],
                "effects": {"a|x": 1, "b|x": 1},
                "refinement": {
                    "continuations": ["y"],
                    "effects": {"a|y": 1, "b|y": 2},
                },
            }
        )
        self.assertTrue(result["refinement"]["monotone_refinement"])
        self.assertEqual(result["refinement"]["new_class_count"], 2)

    def test_missing_effect_fails(self) -> None:
        result = future_effect_quotient(
            {"histories": ["a"], "continuations": ["x"], "effects": {}}
        )
        self.assertEqual(result["state"], "FAIL")

    def test_high_impact_requires_plural_models(self) -> None:
        model = WorldModel.from_dict(
            {
                "id": "m1",
                "family": "f1",
                "structure": {"x": 1},
                "predictions": {"p": {"yes": 1.0}},
            }
        )
        probe = CandidateProbe.from_dict(
            {"id": "p", "cost": 1, "reversible": True, "authorised_by": "A"}
        )
        result = audit_world_models([model], [probe], ImpactLevel.HIGH)
        self.assertEqual(result["state"], "WARN")
        self.assertEqual(result["automatic_external_action_authority"], 0)

    def test_reversible_authorised_probe_selected(self) -> None:
        m1 = WorldModel.from_dict(
            {"id": "m1", "family": "f1", "structure": {"x": 1}, "predictions": {"p": {"a": 0.9, "b": 0.1}}}
        )
        m2 = WorldModel.from_dict(
            {"id": "m2", "family": "f2", "structure": {"y": 2}, "predictions": {"p": {"a": 0.1, "b": 0.9}}}
        )
        probe = CandidateProbe.from_dict(
            {"id": "p", "cost": 1, "reversible": True, "authorised_by": "A"}
        )
        result = audit_world_models([m1, m2], [probe], ImpactLevel.HIGH)
        self.assertEqual(result["recommended_probe"]["probe_id"], "p")


if __name__ == "__main__":
    unittest.main()
