from __future__ import annotations

import unittest

from citm_forge.information import (
    audit_information_contract,
    bayes_risk,
    compose_channels,
    entropy,
    mutual_information,
    validate_distribution,
)


class InformationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.source = {"x0": 0.5, "x1": 0.5}
        self.first = {"x0": {"y0": 0.9, "y1": 0.1}, "x1": {"y0": 0.2, "y1": 0.8}}
        self.second = {"y0": {"z0": 0.85, "z1": 0.15}, "y1": {"z0": 0.25, "z1": 0.75}}

    def test_entropy_fair_bit(self) -> None:
        self.assertAlmostEqual(entropy(self.source), 1.0)

    def test_mutual_information_nonnegative(self) -> None:
        self.assertGreaterEqual(mutual_information(self.source, self.first), 0.0)

    def test_data_processing(self) -> None:
        composed = compose_channels(self.first, self.second)
        self.assertLessEqual(mutual_information(self.source, composed), mutual_information(self.source, self.first) + 1e-9)

    def test_invalid_distribution(self) -> None:
        with self.assertRaises(ValueError):
            validate_distribution({"a": 0.8, "b": 0.8})

    def test_bayes_risk_full_information(self) -> None:
        loss = {"x0": {"a0": 0, "a1": 1}, "x1": {"a0": 1, "a1": 0}}
        result = bayes_risk(self.source, loss, {"x0": "x0", "x1": "x1"})
        self.assertEqual(result["risk"], 0.0)

    def test_contract_audit(self) -> None:
        result = audit_information_contract(
            {
                "source_distribution": self.source,
                "channel_y_given_x": self.first,
                "channel_z_given_y": self.second,
            }
        )
        self.assertEqual(result["state"], "PASS")
        self.assertTrue(result["metrics"]["data_processing_holds"])


if __name__ == "__main__":
    unittest.main()
