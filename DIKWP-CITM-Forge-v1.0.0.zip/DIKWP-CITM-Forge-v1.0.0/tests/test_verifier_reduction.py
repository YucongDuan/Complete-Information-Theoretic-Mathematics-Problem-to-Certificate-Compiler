from __future__ import annotations

import unittest

from citm_forge.model import ProofObligation, ReductionContract
from citm_forge.reduction import audit_reduction
from citm_forge.verifier import (
    generate_goldbach_witnesses,
    is_prime,
    verify_goldbach_finite,
    verify_obligation,
)


class VerifierReductionTests(unittest.TestCase):
    def test_prime(self) -> None:
        self.assertTrue(is_prime(997))
        self.assertFalse(is_prime(999))

    def test_goldbach_generation(self) -> None:
        witnesses = generate_goldbach_witnesses(4, 100)
        self.assertIn("100", witnesses)

    def test_goldbach_verification(self) -> None:
        result = verify_goldbach_finite({"start": 4, "end": 100, "witnesses": "GENERATE"})
        self.assertEqual(result["state"], "VERIFIED")
        self.assertIn("not a proof", result["scope_boundary"])

    def test_bad_witness_fails(self) -> None:
        result = verify_goldbach_finite({"start": 4, "end": 4, "witnesses": {"4": [1, 3]}})
        self.assertEqual(result["state"], "FAILED")

    def test_external_obligation_not_fabricated(self) -> None:
        obligation = ProofObligation.from_dict(
            {"id": "o", "claim": "x", "scope": "global", "verifier": {"kind": "external"}}
        )
        self.assertEqual(verify_obligation(obligation)["state"], "EXTERNAL")

    def test_reduction_firewall(self) -> None:
        reduction = ReductionContract.from_dict(
            {
                "id": "r",
                "source_claim": "A",
                "target_claim": "B",
                "forward_map": "f",
                "backward_map": "g",
                "soundness_obligation_id": "s",
                "completeness_obligation_id": "c",
                "target_verification_obligation_id": "t",
                "scope": "global",
            }
        )
        results = {"s": {"state": "EXTERNAL"}, "c": {"state": "EXTERNAL"}, "t": {"state": "VERIFIED"}}
        audit = audit_reduction(reduction, results)
        self.assertEqual(audit["claim_state"], "REDUCTION_ONLY")
        self.assertTrue(audit["firewall"])


if __name__ == "__main__":
    unittest.main()
