from __future__ import annotations

import copy
import json
import tempfile
import unittest
from pathlib import Path

from citm_forge.compiler import ForgeCompiler
from citm_forge.errors import IntegrityError
from citm_forge.manifest import build_manifest, verify_manifest
from common import reference_raw


class CompilerManifestTests(unittest.TestCase):
    def test_end_to_end(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            result = ForgeCompiler().compile(reference_raw(), Path(tmp) / "out")
            self.assertEqual(result.certificate["global_closure_claim"], "NOT_ISSUED")
            self.assertEqual(result.certificate["external_domain_settlement"], "NOT_ESTABLISHED")
            self.assertEqual(result.audit["native_core"]["roundtrip"]["state"], "PASS")
            self.assertTrue((result.output_directory / "ledger.jsonl").is_file())

    def test_overclaim_refused(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            result = ForgeCompiler().compile(reference_raw(), Path(tmp) / "out")
            states = {item["id"]: item["issued_state"] for item in result.certificate["claim_results"]}
            self.assertEqual(states["CL-GLOBAL"], "REFUSED_OVERCLAIM")
            self.assertEqual(states["CL-FINITE"], "VERIFIED_WITHIN_DECLARED_SCOPE")

    def test_deterministic_run_hash(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            compiler = ForgeCompiler()
            first = compiler.compile(reference_raw(), Path(tmp) / "a")
            second = compiler.compile(reference_raw(), Path(tmp) / "b")
            self.assertEqual(first.certificate["run_hash"], second.certificate["run_hash"])
            self.assertEqual(first.certificate["ledger_head_hash"], second.certificate["ledger_head_hash"])

    def test_manifest_verifies(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.txt").write_text("a", encoding="utf-8")
            (root / "b.txt").write_text("b", encoding="utf-8")
            manifest = build_manifest(root)
            self.assertTrue(verify_manifest(root, manifest)["valid"])

    def test_manifest_tamper_detected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            path = root / "a.txt"
            path.write_text("a", encoding="utf-8")
            manifest = build_manifest(root)
            path.write_text("changed", encoding="utf-8")
            with self.assertRaises(IntegrityError):
                verify_manifest(root, manifest)

    def test_high_impact_single_world_warns(self) -> None:
        raw = reference_raw()
        raw["world_models"] = raw["world_models"][:1]
        with tempfile.TemporaryDirectory() as tmp:
            result = ForgeCompiler().compile(raw, Path(tmp) / "out")
            self.assertEqual(result.audit["world_models"]["state"], "WARN")


if __name__ == "__main__":
    unittest.main()
