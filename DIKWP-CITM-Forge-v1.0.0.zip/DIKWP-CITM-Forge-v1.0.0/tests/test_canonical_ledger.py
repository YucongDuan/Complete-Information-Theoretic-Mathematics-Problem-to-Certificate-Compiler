from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from citm_forge.canonical import canonical_json, sha256_object
from citm_forge.errors import IntegrityError
from citm_forge.ledger import HashChainLedger


class CanonicalLedgerTests(unittest.TestCase):
    def test_canonical_key_order(self) -> None:
        self.assertEqual(canonical_json({"b": 2, "a": 1}), '{"a":1,"b":2}')

    def test_object_hash_stable(self) -> None:
        self.assertEqual(sha256_object({"a": 1, "b": 2}), sha256_object({"b": 2, "a": 1}))

    def test_ledger_roundtrip(self) -> None:
        ledger = HashChainLedger()
        ledger.append("S1", "A", {"x": 1})
        ledger.append("S2", "B", {"y": 2})
        loaded = HashChainLedger.from_jsonl(ledger.to_jsonl())
        self.assertEqual(loaded.verify()["event_count"], 2)
        self.assertEqual(loaded.head_hash, ledger.head_hash)

    def test_ledger_tamper_detected(self) -> None:
        ledger = HashChainLedger()
        ledger.append("S1", "A", {"x": 1})
        item = json.loads(ledger.to_jsonl())
        item["payload"]["x"] = 2
        with self.assertRaises(IntegrityError):
            HashChainLedger.from_jsonl(json.dumps(item) + "\n")

    def test_empty_ledger_valid(self) -> None:
        self.assertTrue(HashChainLedger().verify()["valid"])


if __name__ == "__main__":
    unittest.main()
