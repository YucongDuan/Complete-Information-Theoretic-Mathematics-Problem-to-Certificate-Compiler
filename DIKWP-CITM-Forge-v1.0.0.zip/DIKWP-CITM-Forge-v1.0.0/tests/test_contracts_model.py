from __future__ import annotations

import copy
import unittest

from citm_forge.contracts import audit_problem_contract, audit_quantifiers
from citm_forge.errors import ValidationError
from citm_forge.model import ProblemContract, Project
from common import reference_raw


class ContractsModelTests(unittest.TestCase):
    def test_contract_eight_dimensions(self) -> None:
        contract = Project.from_dict(reference_raw()).problem_contract
        audit = audit_problem_contract(contract)
        self.assertEqual(len(audit["dimensions"]), 8)
        self.assertEqual(audit["state"], "PASS")

    def test_finite_universal_warning(self) -> None:
        contract = Project.from_dict(reference_raw()).problem_contract
        audit = audit_quantifiers(contract)
        self.assertEqual(audit["state"], "WARN")
        self.assertTrue(audit["has_universal"])
        self.assertTrue(audit["finite_scope"])

    def test_duplicate_records_fail(self) -> None:
        raw = reference_raw()
        raw["records"].append(copy.deepcopy(raw["records"][0]))
        project = Project.from_dict(raw)
        from citm_forge.routes import RouteAudit
        with self.assertRaises(ValidationError):
            RouteAudit(project.records, project.routes, project.aliases).validate()

    def test_missing_project_id_fails(self) -> None:
        raw = reference_raw()
        del raw["metadata"]["project_id"]
        with self.assertRaises(ValidationError):
            Project.from_dict(raw)


if __name__ == "__main__":
    unittest.main()
