from __future__ import annotations

import unittest

from citm_forge.model import ConceptAlias, Project, Route, SemanticRecord
from citm_forge.routes import ALL_ROUTE_KINDS, RouteAudit
from common import reference_raw


class RouteTests(unittest.TestCase):
    def setUp(self) -> None:
        self.project = Project.from_dict(reference_raw())
        self.audit = RouteAudit(self.project.records, self.project.routes, self.project.aliases)

    def test_twenty_five_permitted_kinds(self) -> None:
        self.assertEqual(len(ALL_ROUTE_KINDS), 25)

    def test_reference_route_graph_valid(self) -> None:
        result = self.audit.validate()
        self.assertNotEqual(result["state"], "FAIL")
        self.assertEqual(result["closure_vector"], "11111")

    def test_w_reaches_forward_p(self) -> None:
        self.assertEqual(self.audit.w_to_forward_p_audit()["state"], "PASS")

    def test_p_outputs_explicit(self) -> None:
        self.assertEqual(self.audit.p_output_audit()["state"], "PASS")

    def test_roundtrip_complete(self) -> None:
        self.assertEqual(self.audit.roundtrip_audit()["state"], "PASS")

    def test_route_collision_visible(self) -> None:
        extra = Route.from_dict(
            {
                "id": "R_COLLIDE",
                "source": "D_INPUT",
                "target": "I_SCOPE",
                "generated_content": "A second, intentionally different generated relation.",
            }
        )
        result = RouteAudit(self.project.records, self.project.routes + (extra,), self.project.aliases).validate()
        self.assertEqual(result["state"], "WARN")
        self.assertTrue(result["collisions"])

    def test_unknown_route_target_fails(self) -> None:
        extra = Route.from_dict(
            {"id": "R_BAD", "source": "D_INPUT", "target": "NOPE", "generated_content": "bad"}
        )
        result = RouteAudit(self.project.records, self.project.routes + (extra,), self.project.aliases).validate()
        self.assertEqual(result["state"], "FAIL")


if __name__ == "__main__":
    unittest.main()
