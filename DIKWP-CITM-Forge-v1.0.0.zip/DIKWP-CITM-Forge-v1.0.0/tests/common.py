from __future__ import annotations

import json
from pathlib import Path


def root() -> Path:
    return Path(__file__).resolve().parents[1]


def reference_raw() -> dict:
    return json.loads((root() / "src/citm_forge/data/reference_project.json").read_text(encoding="utf-8"))
