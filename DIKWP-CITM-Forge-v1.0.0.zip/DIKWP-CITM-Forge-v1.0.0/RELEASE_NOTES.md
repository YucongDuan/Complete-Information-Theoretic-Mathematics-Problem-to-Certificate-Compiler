# DIKWP-CITM Forge 1.0.0 Release Notes

This release converts the books' software appendix and mathematical-machine discipline into a runnable reference implementation. The principal deliverable is not a solver that declares open problems complete. It is an auditable compiler that keeps local verification, information-theoretic reduction, inherited theorem fidelity, external acceptance, and real-world contact in separate ledgers.

The bundled finite Goldbach run demonstrates the boundary: the witness table is checked, the finite claim is certified, the reduction remains `REDUCTION_ONLY`, and the unrestricted `SOLVED` request is recorded as `REFUSED_OVERCLAIM`.
