# Release Checklist

- [ ] Review source, schemas, examples, and documentation.
- [ ] Run `./run_tests.sh`.
- [ ] Run `python scripts/build_release.py`.
- [ ] Compare the reference run hash with the intended release record.
- [ ] Inspect `RELEASE_MANIFEST.json`, `RELEASE_VERIFICATION.json`, and archive SHA-256.
- [ ] Confirm `global_closure_claim = NOT_ISSUED`.
- [ ] Confirm no DOI, signature, institution, repository release, or external acceptance is fabricated.
- [ ] Create an authenticated commit and signed tag under the authorised account.
- [ ] Publish the exact archive and standalone demo.
- [ ] Archive the exact version; add DOI only after issuance.
- [ ] Preserve predecessor hashes and document successor changes.
