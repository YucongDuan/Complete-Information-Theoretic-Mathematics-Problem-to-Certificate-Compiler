# Governance

## Maintainer authority

Yucong Duan is the principal maintainer and release authority for the reference line. A release must be explicitly authorised through the maintainer's authenticated publication account; this local archive does not itself constitute such publication.

## Decision rules

- source and authorship provenance are not removed by refactoring;
- backward compatibility does not justify semantic ambiguity;
- security, quantifier fidelity, and overclaim boundaries override feature convenience;
- substantial design changes require a written rationale and migration record;
- competing implementations may coexist if they preserve the schemas, conformance tests, and attribution obligations.

## Release classes

- patch: bug/security/documentation correction without contract change;
- minor: backward-compatible verifier, audit, or interface extension;
- major: schema or certificate semantics change requiring explicit migration.

## External authority

No contributor, model, CI job, or local runtime can publish, sign, create a DOI, or claim institutional endorsement without the authorised account holder's explicit action.
