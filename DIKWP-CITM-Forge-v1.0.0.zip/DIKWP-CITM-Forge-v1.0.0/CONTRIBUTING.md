# Contributing

1. Open an issue describing the object contract and the relation being changed.
2. Preserve existing record identifiers and public schema fields.
3. Add a successor version rather than silently changing certificate meaning.
4. Add tests for the new invariant and at least one negative case.
5. Keep the trusted core dependency-free unless a separately audited adapter is proposed.
6. Do not introduce a status that turns finite/local/protocol results into unrestricted mathematical settlement.
7. Update `CHANGELOG.md`, `docs/SOURCE_MAPPING.md`, schemas, and reference outputs when applicable.
8. Run `./run_tests.sh` and `python scripts/verify_release.py`.

Contributions must comply with the applicable file license and preserve NOTICE/source attribution.
