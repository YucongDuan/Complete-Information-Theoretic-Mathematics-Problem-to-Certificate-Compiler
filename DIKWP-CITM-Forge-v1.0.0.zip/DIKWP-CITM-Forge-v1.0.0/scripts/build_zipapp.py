#!/usr/bin/env python3
from __future__ import annotations

import zipapp
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
source = ROOT / "src"
target = ROOT / "dist/DIKWP_CITM_Forge.pyz"
target.parent.mkdir(parents=True, exist_ok=True)
zipapp.create_archive(
    source,
    target,
    interpreter="/usr/bin/env python3",
    main="citm_forge.cli:main",
    compressed=True,
)
target.chmod(0o755)
print(target)
