#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from citm_forge.ledger import HashChainLedger  # noqa: E402
from citm_forge.manifest import verify_manifest  # noqa: E402


def main() -> int:
    manifest_path = ROOT / "RELEASE_MANIFEST.json"
    if not manifest_path.is_file():
        print("RELEASE_MANIFEST.json is missing", file=sys.stderr)
        return 2
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    result = verify_manifest(ROOT, manifest)
    ledger = HashChainLedger.read(ROOT / "outputs/reference/main/ledger.jsonl").verify()
    completed = subprocess.run(
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"],
        cwd=ROOT,
        env={**__import__("os").environ, "PYTHONPATH": str(ROOT / "src")},
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    print(completed.stdout)
    summary = {
        "manifest": result,
        "reference_ledger": ledger,
        "tests_exit_code": completed.returncode,
        "zipapp_exists": (ROOT / "dist/DIKWP_CITM_Forge.pyz").is_file(),
        "offline_demo_exists": (ROOT / "web/DIKWP_CITM_Forge_Offline_Demo.html").is_file(),
        "global_closure_claim": "NOT_ISSUED",
    }
    print(json.dumps(summary, indent=2, sort_keys=True))
    return 0 if completed.returncode == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
