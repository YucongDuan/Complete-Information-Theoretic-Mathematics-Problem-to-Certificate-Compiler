#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "sbom.spdx.json"

sbom = {
    "spdxVersion": "SPDX-2.3",
    "dataLicense": "CC0-1.0",
    "SPDXID": "SPDXRef-DOCUMENT",
    "name": "DIKWP-CITM-Forge-v1.0.0-SBOM",
    "documentNamespace": "https://example.invalid/spdx/dikwp-citm-forge/1.0.0/local-reference",
    "creationInfo": {
        "created": "2026-08-23T00:00:00Z",
        "creators": ["Person: Yucong Duan", "Person: Feng Wang", "Tool: DIKWP-CITM Forge release scripts 1.0.0"],
        "licenseListVersion": "3.25"
    },
    "packages": [
        {
            "name": "dikwp-citm-forge",
            "SPDXID": "SPDXRef-Package-DIKWP-CITM-Forge",
            "versionInfo": "1.0.0",
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "licenseConcluded": "AGPL-3.0-or-later",
            "licenseDeclared": "AGPL-3.0-or-later",
            "copyrightText": "Copyright (c) 2026 Yucong Duan and Feng Wang",
            "supplier": "Person: Yucong Duan",
            "externalRefs": [
                {
                    "referenceCategory": "PACKAGE-MANAGER",
                    "referenceType": "purl",
                    "referenceLocator": "pkg:pypi/dikwp-citm-forge@1.0.0"
                }
            ]
        },
        {
            "name": "Python Standard Library",
            "SPDXID": "SPDXRef-Package-Python-Stdlib",
            "versionInfo": ">=3.11",
            "downloadLocation": "NOASSERTION",
            "filesAnalyzed": False,
            "licenseConcluded": "Python-2.0",
            "licenseDeclared": "Python-2.0",
            "copyrightText": "NOASSERTION",
            "supplier": "Organization: Python Software Foundation"
        }
    ],
    "relationships": [
        {
            "spdxElementId": "SPDXRef-DOCUMENT",
            "relationshipType": "DESCRIBES",
            "relatedSpdxElement": "SPDXRef-Package-DIKWP-CITM-Forge"
        },
        {
            "spdxElementId": "SPDXRef-Package-DIKWP-CITM-Forge",
            "relationshipType": "DEPENDS_ON",
            "relatedSpdxElement": "SPDXRef-Package-Python-Stdlib"
        }
    ],
    "annotations": [
        {
            "annotationDate": "2026-08-23T00:00:00Z",
            "annotationType": "OTHER",
            "annotator": "Tool: DIKWP-CITM Forge release scripts 1.0.0",
            "comment": "No third-party runtime Python package dependency is declared. Build tooling may use setuptools."
        }
    ]
}
OUTPUT.write_text(json.dumps(sbom, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(OUTPUT)
