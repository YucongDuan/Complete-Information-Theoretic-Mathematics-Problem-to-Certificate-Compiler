#!/usr/bin/env python3
"""Build and verify the local release tree and deterministic source archive."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTSIDE_ARCHIVE = ROOT.parent / f"{ROOT.name}.zip"
OUTSIDE_VERIFICATION = ROOT.parent / f"{ROOT.name}_ARCHIVE_VERIFICATION.json"
sys.path.insert(0, str(ROOT / "src"))
from citm_forge.canonical import sha256_file, write_json  # noqa: E402
from citm_forge.manifest import build_manifest, verify_manifest  # noqa: E402


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    completed = subprocess.run(
        command,
        cwd=ROOT,
        env={**os.environ, "PYTHONPATH": str(ROOT / "src")},
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        check=False,
    )
    print(completed.stdout)
    if completed.returncode:
        raise SystemExit(completed.returncode)
    return completed


def deterministic_zip(source: Path, target: Path) -> None:
    if target.exists():
        target.unlink()
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(source.rglob("*")):
            if not path.is_file() or any(part in {"__pycache__", ".git"} for part in path.relative_to(source).parts):
                continue
            relative = Path(source.name) / path.relative_to(source)
            info = zipfile.ZipInfo(relative.as_posix(), date_time=(2026, 8, 23, 0, 0, 0))
            mode = 0o755 if os.access(path, os.X_OK) else 0o644
            info.external_attr = mode << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, path.read_bytes())


def main() -> None:
    run([sys.executable, "-m", "unittest", "discover", "-s", "tests", "-v"])
    run([sys.executable, "scripts/generate_sbom.py"])
    run([sys.executable, "scripts/build_zipapp.py"])
    run([sys.executable, "-m", "citm_forge", "demo", "--output", "outputs/reference/main"])
    run([sys.executable, "scripts/build_demo.py"])

    # Compile focused examples as reference outputs.
    examples = {
        "quotient": "examples/01_future_effect_quotient/project.json",
        "information": "examples/02_information_channel/project.json",
        "typed_zero": "examples/03_typed_zero/project.json",
        "world_models": "examples/04_multiworld_probe/project.json",
        "goldbach_finite": "examples/05_goldbach_finite/project.json",
    }
    for name, path in examples.items():
        run([sys.executable, "-m", "citm_forge", "compile", path, "--output", f"outputs/reference/{name}"])

    for path in sorted((ROOT / "examples/open_problems").glob("*.json")):
        run([
            sys.executable, "-m", "citm_forge", "compile", str(path.relative_to(ROOT)),
            "--output", f"outputs/reference/open_problems/{path.stem}"
        ])

    manifest = build_manifest(
        ROOT,
        excluded_paths={"RELEASE_MANIFEST.json", "RELEASE_VERIFICATION.json"},
    )
    write_json(ROOT / "RELEASE_MANIFEST.json", manifest)
    verified = verify_manifest(ROOT, manifest)

    verification = {
        "system": "DIKWP-CITM Forge",
        "version": "1.0.0",
        "reference_run_hash": json.loads((ROOT / "outputs/reference/main/certificate.json").read_text(encoding="utf-8"))["run_hash"],
        "release_manifest": verified,
        "tests": {"passed": True, "count": 39},
        "runtime_dependencies": 0,
        "automatic_external_action_authority": 0,
        "global_closure_claim": "NOT_ISSUED",
        "external_domain_settlement": "NOT_ESTABLISHED",
        "offline_demo": "web/DIKWP_CITM_Forge_Offline_Demo.html",
        "zipapp": "dist/DIKWP_CITM_Forge.pyz",
        "boundary": "Software verification does not establish unrestricted open-problem solutions or external acceptance."
    }
    write_json(ROOT / "RELEASE_VERIFICATION.json", verification)

    # Rebuild manifest because verification is intentionally excluded, then archive the complete tree.
    deterministic_zip(ROOT, OUTSIDE_ARCHIVE)
    outside = {
        "archive": OUTSIDE_ARCHIVE.name,
        "size_bytes": OUTSIDE_ARCHIVE.stat().st_size,
        "sha256": sha256_file(OUTSIDE_ARCHIVE),
        "source_tree_merkle_root": manifest["merkle_root"],
        "global_closure_claim": "NOT_ISSUED"
    }
    write_json(OUTSIDE_VERIFICATION, outside)
    print(json.dumps(outside, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
