@echo off
setlocal
set ROOT=%~dp0
cd /d "%ROOT%"
set PYTHONPATH=%ROOT%src;%PYTHONPATH%
python -m unittest discover -s tests -v
endlocal
