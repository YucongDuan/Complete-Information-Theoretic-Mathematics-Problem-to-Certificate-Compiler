@echo off
setlocal
set ROOT=%~dp0
cd /d "%ROOT%"
set PYTHONPATH=%ROOT%src;%PYTHONPATH%
python -m citm_forge demo --output "%ROOT%outputs\demo"
echo.
echo Open: %ROOT%web\DIKWP_CITM_Forge_Offline_Demo.html
endlocal
