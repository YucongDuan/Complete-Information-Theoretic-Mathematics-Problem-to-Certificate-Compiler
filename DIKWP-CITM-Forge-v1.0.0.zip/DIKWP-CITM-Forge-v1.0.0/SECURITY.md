# Security Policy

## Supported version

Version 1.0.x is the current supported line.

## Reporting

Report a vulnerability privately to the project maintainer before public disclosure. Include the affected version, a minimal reproduction, impact, and suggested containment. Do not include credentials, private data, or destructive payloads.

## Security invariants

- project JSON is declarative;
- arbitrary project-supplied code is never executed;
- no network, credentials, messaging, persistence, shell, or physical-control tool is exposed;
- automatic external-action authority is zero;
- local serving binds to loopback by default;
- output paths are bounded and manifests reject traversal;
- unsupported verifier kinds remain open.

The reference implementation has not undergone an external penetration test or formal verification.
