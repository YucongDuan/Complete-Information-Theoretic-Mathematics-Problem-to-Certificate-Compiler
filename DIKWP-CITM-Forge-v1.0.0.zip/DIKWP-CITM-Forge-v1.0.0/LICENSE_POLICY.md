# License Policy

| Material | License | SPDX identifier |
|---|---|---|
| `src/`, `tests/`, `scripts/`, shell/batch launchers | GNU Affero General Public License v3 or later | `AGPL-3.0-or-later` |
| `schemas/`, public conformance interfaces | Apache License 2.0 | `Apache-2.0` |
| `docs/`, `README*`, `examples/`, offline explanatory dashboard | Creative Commons Attribution 4.0 International | `CC-BY-4.0` |
| Generated run outputs | Same license as the input example unless separately declared; reference outputs are CC BY 4.0 | `CC-BY-4.0` |

A source file can override this table only through an explicit SPDX header and a compatible notice. Theoretical attribution and NOTICE preservation remain required where legally applicable.
