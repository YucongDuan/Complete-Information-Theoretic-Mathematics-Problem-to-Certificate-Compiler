# Code of Conduct

Participants must discuss claims, code, evidence, and consequences without harassment, discrimination, impersonation, credit erasure, or coercive disclosure. Technical disagreement must preserve the other party's right to inspect evidence, refuse an action, and maintain a distinct model when the object contract remains unresolved.

Maintainers may remove contributions or participation that introduce malicious code, fabricated credentials or endorsements, plagiarism, targeted abuse, or repeated deliberate overclaiming.
